# Catur Multiplayer — Android Studio (Kotlin)

Game catur lengkap untuk Android: lawan komputer, 2 pemain di 1 HP, dan multiplayer
via **WiFi LAN / Hotspot** atau **Bluetooth**. Tanpa library eksternal (hanya AndroidX + Material).

> Status: kode ditulis dan diperiksa secara statis, logika aturan catur diverifikasi dengan perft.
> Proyek **belum pernah dikompilasi/dijalankan di perangkat** oleh pembuatnya. Kalau Gradle Sync/Run
> memberi error, salin pesannya untuk diperbaiki.

---------------------------------------------------------------------------------------------------

## DAFTAR ISI
1. [Persyaratan & cara menjalankan](#1-persyaratan--cara-menjalankan)
2. [Daftar fitur](#2-daftar-fitur)
3. [Tutorial bermain](#3-tutorial-bermain)
4. [Struktur folder & keterangan file](#4-struktur-folder--keterangan-file)
5. [Penjelasan detail per file](#5-penjelasan-detail-per-file)
6. [Cara kerja fitur penting](#6-cara-kerja-fitur-penting)
7. [Protokol jaringan](#7-protokol-jaringan)
8. [Kustomisasi (mengubah isi game)](#8-kustomisasi)
9. [Pengujian](#9-pengujian)
10. [Troubleshooting](#10-troubleshooting)
11. [Keterbatasan yang diketahui](#11-keterbatasan-yang-diketahui)
12. [Referensi & asal aset (papan, bidak, suara, ikon)](#12-referensi--asal-aset)

---------------------------------------------------------------------------------------------------

## 1. Persyaratan & cara menjalankan

**Persyaratan**
- Android Studio versi terbaru (mendukung AGP 8.7), JDK 17 (bawaan Android Studio).
- Dua HP Android asli, Android 7.0+ (minSdk 24) untuk uji multiplayer. Bluetooth & hotspot
  **tidak berfungsi di emulator**.

**Langkah**
1. Ekstrak zip → Android Studio → **File ▸ Open** → pilih folder `CaturMultiplayer`.
2. Tunggu *Gradle Sync* selesai (butuh internet; mengunduh Gradle 8.9 dan dependensi).
   - Folder ini tidak membawa `gradle-wrapper.jar`/`gradlew`. Android Studio memakai
     `gradle/wrapper/gradle-wrapper.properties`. Jika Anda ingin `gradlew`, jalankan `gradle wrapper`.
   - Jika Android Studio menawarkan *upgrade* AGP/Gradle, boleh diterima.
3. Aktifkan **Opsi Pengembang ▸ USB debugging** di HP, sambungkan, pilih perangkat, tekan **Run ▶**.
4. Pasang aplikasi di **kedua** HP untuk mode multiplayer.

---------------------------------------------------------------------------------------------------

## 2. Daftar fitur

**Aturan catur (engine/)**
- Gerak semua bidak, tangkap, skak, **skakmat**, **stalemate**.
- Raja tidak pernah bisa dimakan: langkah yang membuat raja sendiri diserang dibuang dari daftar
  langkah legal. Bidak yang terkena *pin* tidak bisa meninggalkan garis.
- **Rokade** kedua sisi untuk Putih & Hitam (ditolak bila sedang skak, melewati/mendarat di petak
  diserang, raja/benteng pernah jalan, atau benteng sudah dimakan).
- **En passant** (hanya berlaku 1 giliran).
- **Promosi pion** dengan pilihan Ratu / Benteng / Gajah / Kuda (dialog pilihan).
- **Remis**: stalemate, aturan 50 langkah, posisi berulang 3 kali, material tidak cukup,
  kesepakatan (tawaran seri), dan hasil lain: menyerah, waktu habis.
- Notasi SAN (Nf3, exd5, O-O, e8=Q+, Qh4#) dan ekspor **PGN** ke clipboard.

**Mode permainan**
- **Lawan Komputer**: 4 level, pilih warna (Putih/Hitam/Acak) dan waktu.
- **2 Pemain (1 HP)**: bergantian di satu layar, opsi putar papan otomatis.
- **Online via WiFi/Hotspot** (TCP) dan **Bluetooth** (RFCOMM).

**Tampilan & kontrol**
- Jam catur per pemain (Tanpa batas / 3 / 5 / 10 / 15 / 30 menit), **durasi partai** berjalan.
- Bidak yang dimakan + **poin material** (pion 1, kuda/gajah 3, benteng 5, ratu 9) dan selisih "+n".
- Sorotan langkah terakhir, petak terpilih, titik langkah legal, raja skak berwarna merah.
- Tombol: **Undo**, **Putar** papan, **Seri**, **Menyerah**, **Menu** (partai baru, salin PGN, chat, keluar).
- **Rotasi layar** portrait ↔ landscape tanpa mengulang partai.
- **Efek suara**: langkah, makan, skak, rokade, promosi, mulai, selesai.
- Tema papan (4 pilihan) dengan pratinjau, petunjuk langkah legal bisa dimatikan.

**Online**
- **Pause otomatis** saat koneksi putus + **reconnect otomatis** + hitung mundur 3 detik sebelum lanjut.
- Tawaran seri, menyerah, **chat**, **main lagi** (warna ditukar).
- Setiap langkah dari lawan divalidasi ulang oleh aturan catur (pesan curang/rusak ditolak).

**Poin & statistik**
- Rating Elo (awal 800), perubahan poin tampil di dialog hasil.
- Layar Statistik: rating, menang/seri/kalah, riwayat 50 partai (tanggal, lawan, hasil, poin, durasi, langkah).

---------------------------------------------------------------------------------------------------

## 3. Tutorial bermain

### 3.1 Lawan Komputer
1. Menu utama ▸ **Lawan Komputer**.
2. Pilih **warna**, **waktu**, **level** (1 Pemula ±400, 2 Menengah ±800, 3 Mahir ±1200, 4 Kuat ±1600) ▸ **Mulai**.
3. Ketuk bidak Anda → muncul titik di petak tujuan legal → ketuk petak tujuan.
4. Pion mencapai ujung papan → dialog promosi muncul → pilih bidak.
5. Rokade: ketuk raja, lalu ketuk petak 2 langkah ke arah benteng (titik rokade akan muncul bila legal).
6. **Undo** memundurkan sampai giliran Anda lagi (tidak tersedia setelah partai ber-rating selesai).
7. **Seri**: komputer menerima hanya bila sudah ≥10 langkah dan ia tidak sedang unggul.
8. **Menyerah**: konfirmasi → Anda kalah, rating turun.

### 3.2 2 Pemain (1 HP)
Menu ▸ **2 Pemain** ▸ pilih waktu ▸ Mulai. Giliran bergantian di satu layar. Aktifkan
*Putar papan otomatis* di Pengaturan agar papan menghadap pemain yang sedang jalan.
Mode ini **tidak** mengubah rating. **Menyerah** = pihak yang sedang giliran menyerah.

### 3.3 Multiplayer via WiFi (jaringan yang sama)
Syarat: kedua HP tersambung ke **WiFi yang sama**.
1. HP A: Menu ▸ **Main via WiFi / Hotspot** ▸ pilih warna & waktu ▸ **Buat Room**.
   Layar menampilkan "IP HP ini: 192.168.x.x (port 8765)".
2. HP B: Menu ▸ **Main via WiFi / Hotspot** ▸ isi kolom IP dengan IP dari HP A ▸ **Gabung**.
3. Setelah tersambung, kedua HP otomatis masuk permainan. Host menentukan warna & waktu.

### 3.4 Multiplayer via Hotspot (tanpa router)
1. HP A nyalakan **Hotspot** (Pengaturan HP).
2. HP B sambungkan WiFi ke hotspot HP A.
3. HP A: **Buat Room** (seperti 3.3). HP B: buka lobi — kolom IP **otomatis terisi IP gateway**
   (biasanya `192.168.43.1`, itu IP HP A). Tekan **Gabung**.

### 3.5 Multiplayer via Bluetooth
1. (Disarankan) pairing kedua HP dulu di Pengaturan Bluetooth HP.
2. HP A: Menu ▸ **Main via Bluetooth** ▸ **Jadi Host** → izinkan permintaan Bluetooth/terlihat 5 menit.
3. HP B: Menu ▸ **Main via Bluetooth** ▸ **Cari Perangkat** → ketuk nama HP A di daftar.
4. Izin yang diminta: Android 12+ "Perangkat di sekitar" (Connect/Scan/Advertise);
   Android 11 ke bawah: Lokasi (syarat sistem untuk scan Bluetooth).

### 3.6 Selama partai online
- **Seri**: kirim tawaran; lawan bisa Terima/Tolak. **Menyerah**: langsung kalah.
- **Menu ▸ Chat**: kirim pesan singkat; pesan masuk tampil sebagai Toast.
- **Koneksi putus**: layar gelap "Permainan dijeda" → jam berhenti → sambung ulang otomatis →
  "Tersambung kembali! Melanjutkan dalam 3…2…1" → lanjut. Tombol **Keluar** di layar jeda
  dihitung menyerah.
- Setelah selesai: **Main lagi** → lawan diminta menerima → partai baru, **warna ditukar**.

### 3.7 Pengaturan & Statistik
- **Pengaturan**: nama pemain (dipakai di online), tema papan, petunjuk langkah, suara, putar papan otomatis.
- **Statistik**: rating, rekor, riwayat; tombol **Reset statistik** mengembalikan rating ke 800.

---------------------------------------------------------------------------------------------------

## 4. Struktur folder & keterangan file

```
CaturMultiplayer/
├── settings.gradle.kts            Nama proyek & modul (:app), repositori Gradle
├── build.gradle.kts               Versi plugin Android (8.7.3) & Kotlin (2.0.21)
├── gradle.properties              Opsi Gradle (AndroidX, memori)
├── gradle/wrapper/gradle-wrapper.properties   Versi Gradle yang dipakai (8.9)
├── .gitignore                     Berkas yang tidak ikut Git
├── README.md                      Dokumen ini
└── app/
    ├── build.gradle.kts           SDK (min 24, target/compile 35), dependensi, opsi build
    ├── proguard-rules.pro         Aturan R8 (kosong, minify dimatikan)
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml    Izin WiFi/Bluetooth, daftar Activity, rotasi bebas
        │   ├── java/id/catur/game/
        │   │   ├── MainActivity.kt           Menu utama + dialog pilihan partai
        │   │   ├── GameActivity.kt           Layar permainan (inti UI)
        │   │   ├── WifiLobbyActivity.kt      Lobi WiFi/Hotspot
        │   │   ├── BluetoothLobbyActivity.kt Lobi Bluetooth + izin runtime
        │   │   ├── SettingsActivity.kt       Pengaturan
        │   │   ├── StatsActivity.kt          Statistik & riwayat
        │   │   ├── engine/                   OTAK CATUR (murni Kotlin, tanpa Android)
        │   │   │   ├── Piece.kt, Move.kt, Position.kt, ChessGame.kt, ChessAi.kt
        │   │   ├── network/                  KOMUNIKASI ANTAR HP
        │   │   │   ├── Protocol.kt, GameConnection.kt, StreamConnection.kt
        │   │   │   ├── WifiConnector.kt, BluetoothConnector.kt
        │   │   │   ├── Handshake.kt, ReconnectStrategy.kt, ConnectionHolder.kt
        │   │   ├── ui/ChessBoardView.kt      Papan custom (Canvas)
        │   │   └── util/                     Prefs, StatsStore, SoundManager, BoardThemes,
        │   │                                 NetUtils, UiUtils
        │   └── res/
        │       ├── layout/        Layar portrait (+ include_game_options, include_game_overlay)
        │       ├── layout-land/   activity_game.xml versi landscape
        │       ├── values/        strings.xml, arrays.xml, colors.xml, themes.xml
        │       ├── drawable/      bg_clock.xml, bg_clock_active.xml
        │       ├── mipmap-*/      Ikon aplikasi
        │       └── raw/           sfx_move/capture/check/castle/promote/end/start .wav
        └── test/java/id/catur/game/ChessRulesTest.kt   Unit test aturan catur
```

Catatan: folder `tools/gen_sounds.py` (di root proyek) adalah skrip Python pembuat file suara `res/raw/*.wav`; tidak ikut dibuild.

---------------------------------------------------------------------------------------------------

## 5. Penjelasan detail per file

### engine/ — aturan catur (tidak bergantung Android, mudah diuji)
| File | Isi & tanggung jawab |
|---|---|
| `Piece.kt` | Konstanta `PAWN..KING` (1..6). Bidak Putih = angka positif, Hitam = negatif, 0 kosong. `pieceGlyph()` simbol Unicode, `piecePoints()` poin material. |
| `Move.kt` | `Move(from, to, promo)`. Petak 0..63 (0 = a8, 63 = h1). `toWire/fromWire` (kirim via jaringan), `fromUci` ("e2e4", "a7a8q"), `squareName`. Rokade & en passant tidak butuh flag khusus: dikenali dari bentuk langkahnya. |
| `Position.kt` | Satu posisi papan immutable + semua aturan: `isAttacked`, `inCheck`, `pseudoMoves`, **`legalMoves`**, **`apply`** (menjalankan langkah, memindah benteng saat rokade, menghapus pion en passant, mengganti pion saat promosi, memperbarui hak rokade & en passant & jam 50 langkah), `key()` untuk deteksi pengulangan, `fromFen`. |
| `ChessGame.kt` | Riwayat posisi & langkah, validasi `play()`, deteksi akhir (skakmat, stalemate, 50 langkah, 3x berulang, material tidak cukup), `finish()` untuk menyerah/waktu/seri, `undo()`, SAN, `capturedTypes/points`, `toPgn()`. |
| `ChessAi.kt` | AI ringan: negamax + alpha-beta + iterative deepening + quiescence 3 ply, evaluasi material + bonus posisi. `forLevel(1..4)`, `ratingForLevel`, `evaluate`. Dijalankan di thread latar dengan batas waktu. |

### network/ — komunikasi
| File | Isi |
|---|---|
| `Protocol.kt` | Konstanta port (8765), UUID Bluetooth, nama pesan, `build()`/`parse()` (pemisah `|`). |
| `GameConnection.kt` | Kelas dasar koneksi; semua callback ke main thread; menyimpan pesan yang datang saat belum ada listener (penting saat pindah layar); interface `Cancelable`. |
| `StreamConnection.kt` | Implementasi stream: thread pembaca per baris, antrean penulis 1 thread, deteksi putus, `close()` memberi 400 ms agar pesan terakhir (mis. RESIGN) terkirim. |
| `WifiConnector.kt` | `WifiHost` (ServerSocket, reuse-address) dan `WifiClient.connect(ip)` (timeout 5 dtk). |
| `BluetoothConnector.kt` | `BluetoothHost` (RFCOMM listen) dan `BluetoothClient.connect(device)`. |
| `Handshake.kt` | Pertukaran `HELLO` (nama, rating) lalu host kirim `START` (warna lawan, menit, token partai). Menghasilkan `Session`. |
| `ReconnectStrategy.kt` | `HostReconnect` (buka server lagi) dan `ClientReconnect` (coba sambung tiap 2 dtk) untuk WiFi maupun Bluetooth. |
| `ConnectionHolder.kt` | Menitipkan koneksi, status host, token, dan strategi reconnect dari lobi ke `GameActivity`. |

### Activity & UI
| File | Isi |
|---|---|
| `MainActivity.kt` | Menu, tampilan rating, dialog opsi partai (memakai `include_game_options`). |
| `GameActivity.kt` | Pusat permainan: input ketuk, promosi, jam (ticker 200 ms), durasi, AI di thread latar, suara, undo, seri/menyerah/keluar, PGN, chat, hasil & rating, **pause/reconnect/sync/hitung mundur**, **rotasi layar** (`onConfigurationChanged` memuat ulang layout). |
| `WifiLobbyActivity.kt` | Host: tampilkan IP lokal; Klien: IP otomatis dari gateway; jalankan handshake lalu buka `GameActivity`. |
| `BluetoothLobbyActivity.kt` | Izin runtime, minta nyalakan Bluetooth, mode discoverable, daftar perangkat (terpasang + hasil scan), handshake. |
| `SettingsActivity.kt` / `StatsActivity.kt` | Pengaturan (tersimpan otomatis) / statistik & riwayat. |
| `ui/ChessBoardView.kt` | Menggambar petak, koordinat, bidak (outline + isi), sorotan, titik langkah legal, skak merah; papan selalu persegi (lebar di portrait, tinggi di landscape); mendukung papan dibalik. Hanya menampilkan, tanpa aturan. |

### util/
| File | Isi |
|---|---|
| `Prefs.kt` | SharedPreferences: tema, petunjuk, suara, auto-putar, nama pemain. |
| `StatsStore.kt` | Rating Elo (K=32, minimum 100), rekor, riwayat 50 partai (JSON). |
| `SoundManager.kt` | SoundPool, 7 efek dari `res/raw`. |
| `BoardThemes.kt` | Pasangan warna terang/gelap papan. |
| `NetUtils.kt` | Daftar IPv4 lokal; IP gateway WiFi (tebakan IP host hotspot). |
| `UiUtils.kt` | `applySystemBarInsets()` (Android 15 edge-to-edge), `GameOptions` (baca spinner), `formatDuration`. |

### res/
- `layout/include_game_options.xml` — spinner Warna/Waktu/Level (dipakai dialog menu & 2 lobi).
- `layout/include_game_overlay.xml` — lapisan "Permainan dijeda".
- `layout/activity_game.xml` & `layout-land/activity_game.xml` — **ID view harus sama persis** di keduanya.
- `values/arrays.xml` — pilihan waktu (`time_options` ↔ `time_values` harus sejajar), level, promosi, tema.
- `raw/*.wav` — suara (disintesis dari kode; bisa diganti file Anda sendiri dengan nama sama).

---------------------------------------------------------------------------------------------------

## 6. Cara kerja fitur penting

**Alur satu langkah:** ketuk petak → `GameActivity.onSquare` → cari langkah legal dari
`ChessGame.legalMoves()` → (promosi? dialog) → `doMove` → `ChessGame.play` (validasi ulang) →
suara + refresh UI → bila online, kirim `MOVE` → bila mode AI dan giliran komputer, `runAi()`.

**Rotasi layar:** `GameActivity` mendeklarasikan `configChanges` di manifest, sehingga tidak
di-*recreate*. `onConfigurationChanged` memanggil `setupLayout()` yang memuat ulang layout
sesuai orientasi dan menggambar ulang state yang sama (papan, jam, overlay jeda).

**Pause & reconnect:**
1. Putus terdeteksi: socket tertutup (`onClosed`) atau tidak ada pesan >8 dtk (`DEAD_AFTER_MS`;
   `PING` dikirim tiap 2 dtk, `HEARTBEAT_MS`).
2. `enterPause()`: jam berhenti, papan terkunci, overlay tampil, koneksi lama ditutup,
   `ConnectionHolder.reconnect.start{}` dipanggil. Host mendengarkan lagi; klien mencoba tiap 2 dtk.
3. Tersambung: kedua sisi kirim `SYNC|token|langkah|msPutih|msHitam`. Token harus sama
   (partai yang sama). Jika lawan punya langkah lebih banyak, langkah itu dimainkan; jam mengikuti Host.
4. Hitung mundur 3-2-1 (`countdownRunnable`), lalu `resumeGame()` dan permainan berlanjut.
5. Putus lagi saat sinkron/hitung mundur → ulang dari langkah 2.

**Rating Elo:** `E = 1 / (1 + 10^((lawan − saya)/400))`, perubahan = `round(32 × (skor − E))`,
skor 1 / 0,5 / 0. Lawan AI memakai rating tetap per level; online memakai rating lawan dari handshake.
Partai < 2 langkah tidak dinilai. Mundur (undo) dinonaktifkan setelah partai AI dinilai.

**Poin material:** jumlah nilai bidak lawan yang sudah dimakan; selisih ditampilkan "+n" pada pihak unggul.

**Durasi:** dihitung selama partai berjalan dan tidak dijeda; ditampilkan di layar dan dialog hasil.

---------------------------------------------------------------------------------------------------

## 7. Protokol jaringan
Satu pesan = satu baris teks `JENIS|arg|arg`; karakter `|` dan baris baru di argumen diganti otomatis.

| Pesan | Arah | Arti |
|---|---|---|
| `HELLO|nama|rating` | dua arah | Perkenalan saat tersambung |
| `START|warnaLawan(W/B)|menit|token` | Host → Klien | Mulai partai |
| `MOVE|dari,ke,promosi` | dua arah | Satu langkah |
| `RESIGN` | dua arah | Menyerah |
| `DRAW_OFFER` / `DRAW_ACCEPT` / `DRAW_DECLINE` | dua arah | Tawaran seri |
| `REMATCH_REQ|rating` / `REMATCH_OK|rating` | dua arah | Main lagi (warna ditukar) |
| `CHAT|teks` | dua arah | Chat |
| `PING` | dua arah | Detak jantung |
| `SYNC|token|daftarLangkah|msPutih|msHitam` | dua arah | Sinkron setelah tersambung kembali |

WiFi: TCP port `8765`. Bluetooth: RFCOMM, UUID `8f3a1c52-7d44-4b0e-9a56-2c1e6b7d9f01`.
Keduanya memakai `StreamConnection` yang sama, jadi seluruh logika permainan online tidak peduli transportnya.

---------------------------------------------------------------------------------------------------

## 8. Kustomisasi

| Ingin mengubah | Lakukan |
|---|---|
| Kekuatan/kecepatan AI | `ChessAi.forLevel()`: parameter `(kedalaman, batasWaktuMs, peluangSalah)` |
| Rating tiap level AI | `ChessAi.ratingForLevel()` |
| Rating awal / K-factor | `StatsStore.rating()` default 800; konstanta `K` |
| Tema papan baru | Tambah warna di `BoardThemes.lights/darks` **dan** nama di `arrays.xml › theme_names` (urutan sama) |
| Pilihan waktu baru | Tambah di `arrays.xml › time_options` **dan** `time_values` (urutan sama) |
| Suara | Ganti file di `res/raw/` dengan nama sama (`sfx_move.wav`, dst) |
| Teks / bahasa | `values/strings.xml`; bahasa lain: buat `values-en/strings.xml` |
| Port WiFi | `Protocol.PORT` |
| UUID Bluetooth | `Protocol.BT_UUID` (harus sama di kedua HP) |
| Batas deteksi putus / interval ping | `HEARTBEAT_MS`, `DEAD_AFTER_MS` di `GameActivity` |
| Lama hitung mundur lanjut | `countdown = 3` di `GameActivity.handleSync` |
| Gaya bidak | `ChessBoardView.onDraw` (ganti `drawText` dengan gambar bitmap/vector) |
| Ganti package | Android Studio: klik kanan package ▸ Refactor ▸ Rename; lalu ubah `namespace` & `applicationId` di `app/build.gradle.kts` |

---------------------------------------------------------------------------------------------------

## 9. Pengujian
`./gradlew test` menjalankan `ChessRulesTest`:
- **Perft** (jumlah langkah legal pada kedalaman tertentu, angka resmi Chess Programming Wiki):
  posisi awal (20 / 400 / 8.902 / 197.281), Kiwipete (48 / 2.039 / 97.862), dan dua posisi uji
  en passant/pin/promosi/rokade.
- Raja tidak bisa dimakan & tidak pernah dibiarkan skak (60 partai acak).
- Rokade (kedua sisi, Putih & Hitam, ditolak saat skak/melewati serangan, hak hilang).
- En passant (ada & kedaluwarsa), promosi 4 pilihan (dorong & tangkap, Putih & Hitam).
- Skakmat (fool's mate, back-rank), stalemate, 50 langkah, material tidak cukup, pengulangan 3x, undo.

Jaringan, suara, dan UI butuh uji manual di HP (lihat tutorial 3.3–3.6 dan skenario di bawah).

**Skenario uji manual yang disarankan**
1. Mulai partai online, matikan WiFi di salah satu HP 10 detik → harus muncul jeda → nyalakan
   lagi → hitung mundur 3 detik → lanjut dengan posisi & jam sama.
2. Putar HP saat partai berjalan (juga saat dialog promosi tertutup/terbuka) → papan tetap.
3. Menyerah di online → lawan langsung melihat "Anda MENANG", kedua rating berubah.

---------------------------------------------------------------------------------------------------

## 10. Troubleshooting

| Masalah | Penyebab & solusi |
|---|---|
| Gradle Sync gagal | Cek internet; terima upgrade AGP/Gradle; pastikan JDK 17 (Settings ▸ Build ▸ Gradle ▸ Gradle JDK). |
| Gabung WiFi: "Gagal tersambung" | Kedua HP harus satu jaringan; IP salah; WiFi publik/kantor sering memblokir antar-perangkat (*client isolation*) → pakai hotspot. Host harus sudah menekan **Buat Room** lebih dulu. |
| IP kosong di lobi host | WiFi/hotspot belum aktif. |
| Bluetooth tidak menemukan HP | Izin "Perangkat di sekitar"/Lokasi belum diberikan; host belum menekan Jadi Host; pairing dulu di pengaturan Bluetooth. |
| Bluetooth: gagal menyambung berulang | Hapus pairing lalu pairing ulang; matikan-nyalakan Bluetooth; pastikan host masih "menunggu". |
| Bidak tampil sebagai emoji/kotak | Font HP tidak punya simbol catur; ganti ke gambar bitmap (lihat Kustomisasi). |
| Tidak ada suara | Pengaturan ▸ Efek suara; volume media HP. |
| Jeda tidak kunjung lanjut | Kedua HP harus tetap di jaringan/jangkauan yang sama; Host harus tetap di layar permainan. Tombol **Keluar** di overlay mengakhiri (kalah). |

---------------------------------------------------------------------------------------------------

## 11. Keterbatasan yang diketahui
- Proyek belum dikompilasi/diuji di perangkat oleh pembuatnya (lihat catatan di atas).
- Partai tidak disimpan jika aplikasi ditutup paksa/di-kill sistem; tidak ada fitur lanjut partai lama.
- Jam berjalan di masing-masing HP; saat reconnect jam Host dianggap acuan. Selisih kecil (≤ beberapa ratus ms) mungkin terjadi.
- Waktu habis = kalah, tanpa pengecualian "lawan tidak punya material cukup" (aturan FIDE).
- Tidak ada pencarian host otomatis (klien memasukkan IP; IP gateway hotspot terisi otomatis).
- Hanya 2 pemain per partai; tidak ada penonton.
- AI sengaja ringan (kedalaman ≤ 4): cukup menantang pemula–menengah, bukan mesin turnamen.
- Daftar referensi dan asal semua aset ada di bagian 12.

---------------------------------------------------------------------------------------------------

## 12. Referensi & asal aset

### 12.1 Referensi: bagian proyek -> sumber konsep
**Penting:** tidak ada source code yang disalin dari proyek lain. Semua kode ditulis untuk proyek ini;
sumber di bawah dipakai sebagai acuan konsep, aturan, dan data uji.

| Bagian proyek (file) | Acuan | Status |
|---|---|---|
| Aturan catur (`engine/Position.kt`, `ChessGame.kt`) | Peraturan catur FIDE (rokade, en passant, promosi, remis 50 langkah, pengulangan 3x). Teknik: buat langkah "pseudo-legal" lalu buang yang membuat raja sendiri diserang (lihat bagian *Move Generation* di Chess Programming Wiki). | Dari ingatan, belum dibuka ulang |
| Angka uji aturan (`ChessRulesTest.kt`) | Chess Programming Wiki, *Perft Results*: https://www.chessprogramming.org/Perft_Results (posisi awal, Position 2 "Kiwipete", Position 3, Position 4) | Halaman diverifikasi ada. Angka yang sama juga cocok dengan test suite independen `chess-perft.el` (emacs-chess) |
| AI (`engine/ChessAi.kt`) | Chess Programming Wiki: *Negamax*, *Alpha-Beta*, *Quiescence Search*, *Iterative Deepening*, *MVV-LVA* (https://www.chessprogramming.org/MVV-LVA). Wikipedia: *Alpha-beta pruning*. | MVV-LVA dan Alpha-beta terverifikasi sebagai halaman rujukan; sisanya dari ingatan |
| Rating (`util/StatsStore.kt`) | Sistem rating Elo (Wikipedia: *Elo rating system*) | Dari ingatan |
| Bluetooth (`network/BluetoothConnector.kt`) | Android Developers, *Connect Bluetooth devices*: https://developer.android.com/develop/connectivity/bluetooth/connect-bluetooth-devices | Dibuka & dibaca |
| Bluetooth (kelas socket) | Android Developers, `BluetoothSocket`: https://developer.android.com/reference/android/bluetooth/BluetoothSocket | Dibuka & dibaca |
| Izin Bluetooth (`AndroidManifest.xml`, `BluetoothLobbyActivity.kt`) | Android Developers, *Bluetooth permissions*: https://developer.android.com/develop/connectivity/bluetooth/bt-permissions | Dibuka & dibaca |
| WiFi / Hotspot (`network/WifiConnector.kt`) | Dokumentasi Java `java.net.Socket` dan `ServerSocket` (TCP klien-server biasa) | Dari ingatan |
| IP gateway hotspot (`util/NetUtils.kt`) | Android `WifiManager.getDhcpInfo()` (sudah *deprecated* tapi masih berfungsi) | Dari ingatan |
| Suara (`util/SoundManager.kt`) | Android `SoundPool` | Dari ingatan |
| Papan custom (`ui/ChessBoardView.kt`) | Android *Custom View* + `Canvas` | Dari ingatan |

Yang "dari ingatan" artinya saya menyebut nama acuannya tapi tidak membukanya ulang saat menyusun ini.
Cek dulu sebelum dikutip di laporan.

### 12.1b Jurnal / penelitian serupa
| Judul | Isi singkat | Link |
|---|---|---|
| *Aplikasi Game Catur Multiplayer Via Bluetooth Berbasis Android* (penulis tercantum "Puja"; judul Inggris: *Multiplayer Chess Game Via Android-Based Bluetooth App*) | Merancang game catur untuk 2 smartphone Android yang dihubungkan lewat Bluetooth, dibuat dengan Android Studio. Paling dekat dengan proyek ini (versi kami menambah WiFi/Hotspot, AI, jam, rating, dan reconnect). | http://e-journal.potensi-utama.ac.id/ojs/index.php/ITJournal/article/view/373 <br> https://www.researchgate.net/publication/356869165_Aplikasi_Game_Catur_Multiplayer_Via_Bluetooth_Berbasis_Android |

Catatan jujur: hanya jurnal di atas yang saya temukan cukup mirip. Untuk catur via WiFi/hotspot saya
**belum menemukan jurnal khusus**. Teks lengkap jurnal juga belum saya baca; baca sendiri sebelum dikutip
(tahun terbit, nama lengkap penulis, dan volume belum saya verifikasi).

### 12.1c Source code pembanding untuk koneksi Bluetooth & WiFi/Hotspot
Dipakai sebagai **bahan belajar/pembanding**. Kode proyek ini tidak disalin dari sini.

| Untuk | Sumber | Keterangan |
|---|---|---|
| Bluetooth (resmi) | **Android BluetoothChat** (Google/AOSP). Repo: https://github.com/googlesamples/android-BluetoothChat <br> Salinan kode di AOSP: https://android.googlesource.com/platform/development.git/+/50b0f7388b442460bcb9b25305f5275ceae1e5b9/samples/BluetoothChat/src/ | Berisi `BluetoothChat.java`, `BluetoothChatService.java`, `DeviceListActivity.java`. Mendemonstrasikan scan perangkat, daftar perangkat terpasang, RFCOMM socket, connect, dan kirim data. Lisensi Apache 2.0. Sampel lama (Java, API lama): izin Bluetooth Android 12+ **tidak** ada di dalamnya, lihat bagian Bluetooth permissions di dokumentasi. |
| Bluetooth: pola "mendengarkan ulang saat putus" | `BluetoothChatService.java` (versi mirror): https://git.aicp-rom.com/development.git/plain/samples/browseable/BluetoothChat/src/com.example.android.bluetoothchat/BluetoothChatService.java | Saat koneksi hilang, service memulai lagi mode listen. Ide yang sama dipakai `HostReconnect` di proyek ini. |
| WiFi/Hotspot: TCP antar 2 HP via IP + port | **SockChat**: https://github.com/dhvanilp/SockChat | Aplikasi chat P2P Android berbasis Socket; langkahnya: kedua HP satu jaringan, masukkan IP dan port HP lain. Sama dengan pendekatan lobi WiFi kami. |
| WiFi: Socket Android antar perangkat | **AndroidChatExample**: https://github.com/coslor/AndroidChatExample | Chat Android-ke-Android dengan Socket biasa (WiFi sama). Penulisnya juga menyebut ada paket Adhoc/Network Discovery di Android. |
| WiFi Direct (alternatif tanpa router) | **Chat-WIFI-Direct**: https://github.com/fkavache/Chat-WIFI-Direct | Memakai WiFi Direct; satu sisi `ServerSocket` (group owner) dan sisi lain klien. Pendekatan **berbeda** dari proyek ini (kami memakai WiFi/hotspot biasa), bisa jadi pengembangan lanjutan. |
| Kenapa tidak ada auto-discovery host | Diskusi Unity: https://discussions.unity.com/t/hotspot-wifi-multiplayer-game-using-unity/743243 | Broadcast/penemuan otomatis di hotspot dilaporkan tidak konsisten di sebagian perangkat Android. Karena itu proyek ini memakai IP manual + tebakan IP gateway. |

Belum saya audit kualitas kodenya dan lisensi tiap repo selain sampel resmi Android; cek `LICENSE`
sebelum memakai kodenya.

### 12.2 Asal aset tampilan
| Elemen | Asalnya | Catatan |
|---|---|---|
| **Papan** | Digambar langsung oleh kode: `ui/ChessBoardView.kt` (`onDraw`) menggambar 64 kotak dengan `Canvas`. | Tidak ada gambar papan. Koordinat a–h dan 1–8 juga digambar sebagai teks. |
| **Warna papan** | Pasangan warna di `util/BoardThemes.kt`. | Dipilih mengikuti skema populer (hijau-krem mirip tampilan chess.com, cokelat mirip tema "brown" lichess). Nilai heksanya ditulis dari ingatan, bukan disalin dari berkas pihak lain. Bebas diganti. |
| **Bidak** | **Karakter Unicode catur** (blok *Miscellaneous Symbols*, U+2654–U+265F). Kode memakai varian "solid" U+265A–U+265F + penanda teks U+FE0E agar tidak berubah jadi emoji. | Digambar sebagai teks dengan garis tepi (outline). Bidak Putih = isi putih + garis gelap, Hitam = isi gelap + garis terang. **Bentuknya ditentukan font sistem HP** (bisa sedikit berbeda antar merek HP). Tidak ada file gambar bidak, jadi tidak ada lisensi aset pihak ketiga. |
| **Tata letak layar** | Dirancang sendiri di `res/layout` dan `layout-land`. | Susunannya umum di aplikasi catur (nama + jam pemain di atas/bawah papan, daftar langkah, tombol kontrol). Bukan salinan layout aplikasi tertentu. |
| **Jam, bidak dimakan, poin "+n"** | Fitur sendiri, terinspirasi tampilan chess.com. | Hanya gagasan, tidak ada aset yang dipakai. |
| **Efek suara** | **Disintesis** oleh `tools/gen_sounds.py` (gelombang sinus yang meredam + sedikit derau, tanpa rekaman). | Bukan suara dari chess.com/lichess. Jalankan `python tools/gen_sounds.py` untuk membuat ulang, atau ganti `res/raw/sfx_*.wav` dengan suara Anda. |
| **Ikon aplikasi** | Dibuat dengan skrip Python (Pillow): papan kotak-kotak + siluet raja. | Ikon sederhana; ganti lewat *File ▸ New ▸ Image Asset* di Android Studio. |

### 12.3 Library dan lisensi
- AndroidX (appcompat, core-ktx) dan Material Components: lisensi Apache 2.0, diunduh Gradle.
- Tidak ada library jaringan, AI, atau gambar tambahan.
- Font simbol bidak berasal dari sistem Android di HP pengguna.

> Jika proyek ini dikumpulkan sebagai tugas, tulis jujur bahwa bidak memakai karakter Unicode,
> suara dibuat dengan skrip, dan AI memakai algoritma negamax/alpha-beta (bukan model AI/ML).
