# Sintesis efek suara catur (tanpa aset eksternal): bunyi "tok" kayu, tangkap, skak, rokade, promosi, game selesai.
import os, wave, struct, math, random
SR = 22050
random.seed(7)
def env(t, d): return math.exp(-t / d)
def wood(freqs, decay, dur, noise=0.5, noise_decay=0.004, gain=1.0):
    n = int(SR * dur); out = []
    for i in range(n):
        t = i / SR
        s = sum(a * math.sin(2 * math.pi * f * t) * env(t, decay * k) for (f, a, k) in freqs)
        s += noise * (random.random() * 2 - 1) * env(t, noise_decay)
        out.append(s * gain)
    return out
def mix(parts):
    n = max(off + len(p) for off, p in parts); out = [0.0] * n
    for off, p in parts:
        for i, v in enumerate(p): out[off + i] += v
    return out
def tone(f, dur, decay, gain=0.5):
    n = int(SR * dur)
    return [gain * math.sin(2 * math.pi * f * (i / SR)) * env(i / SR, decay) * min(1.0, (i / SR) / 0.004) for i in range(n)]
def save(name, data):
    peak = max(abs(x) for x in data) or 1.0
    data = [x / peak * 0.85 for x in data]
    w = wave.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "res", "raw", name + ".wav"), "wb")
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes(b"".join(struct.pack("<h", int(x * 32767)) for x in data)); w.close()
move = wood([(210, 1.0, 0.030), (520, 0.6, 0.020), (1150, 0.35, 0.012)], 1.0, 0.16, noise=0.9)
cap = mix([(0, wood([(160, 1.0, 0.045), (430, 0.7, 0.030), (980, 0.5, 0.018)], 1.0, 0.22, noise=1.2)),
           (int(SR * 0.045), wood([(240, 0.8, 0.030), (700, 0.4, 0.015)], 1.0, 0.16, noise=0.6))])
check = mix([(0, wood([(200, 1.0, 0.03), (520, 0.6, 0.02)], 1.0, 0.16, noise=0.9)),
             (int(SR * 0.09), tone(880, 0.28, 0.07, 0.55)), (int(SR * 0.19), tone(1175, 0.30, 0.08, 0.5))])
castle = mix([(0, move), (int(SR * 0.13), wood([(260, 1.0, 0.03), (640, 0.6, 0.02)], 1.0, 0.16, noise=0.9))])
promote = mix([(int(SR * 0.0), move)] + [(int(SR * (0.08 + 0.07 * k)), tone(f, 0.25, 0.08, 0.45)) for k, f in enumerate((660, 880, 1320))])
end = mix([(int(SR * 0.16 * k), tone(f, 0.55, 0.16, 0.5)) for k, f in enumerate((523, 659, 784, 1047))])
start = mix([(0, tone(660, 0.22, 0.07, 0.5)), (int(SR * 0.11), tone(990, 0.30, 0.09, 0.5))])
for n, d in (("sfx_move", move), ("sfx_capture", cap), ("sfx_check", check), ("sfx_castle", castle),
             ("sfx_promote", promote), ("sfx_end", end), ("sfx_start", start)):
    save(n, d)
