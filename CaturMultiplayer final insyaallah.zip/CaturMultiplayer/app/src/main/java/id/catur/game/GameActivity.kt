package id.catur.game

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import id.catur.game.engine.BISHOP
import id.catur.game.engine.ChessAi
import id.catur.game.engine.ChessGame
import id.catur.game.engine.EndReason
import id.catur.game.engine.KNIGHT
import id.catur.game.engine.Move
import id.catur.game.engine.Outcome
import id.catur.game.engine.QUEEN
import id.catur.game.engine.ROOK
import id.catur.game.engine.pieceGlyph
import id.catur.game.network.ConnectionHolder
import id.catur.game.network.GameConnection
import id.catur.game.network.Protocol
import id.catur.game.ui.ChessBoardView
import id.catur.game.util.BoardThemes
import id.catur.game.util.GameRecord
import id.catur.game.util.Prefs
import id.catur.game.util.Sfx
import id.catur.game.util.SoundManager
import id.catur.game.util.StatsStore
import id.catur.game.util.applySystemBarInsets
import id.catur.game.util.formatDuration
import java.util.Locale
import java.util.concurrent.Executors

/*
 * FILE: GameActivity.kt  (folder id/catur/game/)
 * Fungsi: LAYAR PERMAINAN untuk 3 mode: lawan komputer (AI), 2 pemain 1 HP, dan online
 * (WiFi/Hotspot/Bluetooth). Menghubungkan papan (ChessBoardView) dengan aturan (ChessGame).
 * Fitur di file ini:
 *  - jam catur, durasi partai, poin material (+selisih) ala chess.com, daftar langkah SAN
 *  - efek suara tiap langkah (biasa/makan/skak/rokade/promosi/selesai)
 *  - tombol Undo, Putar papan, Seri (tawaran), MENYERAH (kalah), Menu (PGN, chat, partai baru)
 *  - rating Elo & riwayat partai (StatsStore)
 *  - ROTASI LAYAR: layout portrait/landscape dimuat ulang tanpa mengulang partai
 *  - PAUSE otomatis saat koneksi online putus, lalu sinkron + hitung mundur 3 detik
 *    setelah tersambung kembali (jeda dikontrol oleh ConnectionHolder.reconnect)
 */
class GameActivity : AppCompatActivity(), GameConnection.Listener {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_WHITE = "white"
        const val EXTRA_MINUTES = "minutes"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_PEER = "peer"
        const val EXTRA_PEER_RATING = "peer_rating"
        const val MODE_AI = "ai"
        const val MODE_LOCAL = "local"
        const val MODE_ONLINE = "online"

        private const val HEARTBEAT_MS = 2000L
        private const val DEAD_AFTER_MS = 8000L

        fun intent(
            ctx: Context, mode: String, myWhite: Boolean, minutes: Int,
            level: Int = 2, peer: String = "", peerRating: Int = 800
        ): Intent = Intent(ctx, GameActivity::class.java)
            .putExtra(EXTRA_MODE, mode)
            .putExtra(EXTRA_WHITE, myWhite)
            .putExtra(EXTRA_MINUTES, minutes)
            .putExtra(EXTRA_LEVEL, level)
            .putExtra(EXTRA_PEER, peer)
            .putExtra(EXTRA_PEER_RATING, peerRating)
    }

    // ---- views
    private lateinit var board: ChessBoardView
    private lateinit var tvTopName: TextView
    private lateinit var tvBottomName: TextView
    private lateinit var tvTopClock: TextView
    private lateinit var tvBottomClock: TextView
    private lateinit var tvTopCaptured: TextView
    private lateinit var tvBottomCaptured: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvDuration: TextView
    private lateinit var tvMoves: TextView
    private lateinit var scrollMoves: ScrollView
    private lateinit var btnUndo: Button
    private lateinit var btnDraw: Button
    private lateinit var btnResign: Button
    private lateinit var overlay: View
    private lateinit var tvOverlay: TextView

    // ---- konfigurasi partai
    private var mode = MODE_AI
    private var myWhite = true
    private var minutes = 0
    private var level = 2
    private var peerName = ""
    private var peerRating = 800
    private var myRating = 800

    // ---- state partai
    private var game = ChessGame()
    private var selected = -1
    private var flipped = false
    private var aiThinking = false
    private var aiToken = 0
    private var whiteMs = 0L
    private var blackMs = 0L
    private var elapsedMs = 0L
    private var lastTick = 0L
    private var gameOverShown = false
    private var resultRecorded = false
    private var lastDelta: Int? = null
    private var ratingBefore = 800
    private var ratingAfter = 800
    private var rematchRequested = false
    private val chatLog = StringBuilder()

    // ---- state online / pause
    private var conn: GameConnection? = null
    private var paused = false
    private var syncReceived = false
    private var countdown = 0
    private var lastRx = 0L
    private var lastPing = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val aiExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "catur-ai").apply { priority = Thread.MIN_PRIORITY }
    }
    private lateinit var sound: SoundManager

    // =====================================================================================
    //  SIKLUS HIDUP
    // =====================================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_AI
        myWhite = intent.getBooleanExtra(EXTRA_WHITE, true)
        minutes = intent.getIntExtra(EXTRA_MINUTES, 0)
        level = intent.getIntExtra(EXTRA_LEVEL, 2)
        peerName = intent.getStringExtra(EXTRA_PEER) ?: getString(R.string.opponent)
        peerRating = intent.getIntExtra(EXTRA_PEER_RATING, 800)
        sound = SoundManager(this)
        sound.enabled = Prefs.sound(this)

        val c = ConnectionHolder.connection
        if (mode == MODE_ONLINE) {
            if (c == null) {
                finish()
                return
            }
            conn = c
        }

        setupLayout()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                confirmExit()
            }
        })
        startNewGame(false)
        conn?.setListener(this)   // dipasang terakhir: pesan tertunda baru diproses setelah UI siap
    }

    /** ROTASI LAYAR: muat ulang layout (portrait <-> landscape) tanpa menyentuh state partai. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setupLayout()
    }

    override fun onResume() {
        super.onResume()
        val now = SystemClock.elapsedRealtime()
        lastTick = now
        lastRx = now
        lastPing = now
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        aiToken++
        aiExecutor.shutdownNow()
        sound.release()
        if (mode == MODE_ONLINE) {
            conn?.setListener(null)
            conn?.close()
            ConnectionHolder.clear()
        }
    }

    private fun setupLayout() {
        setContentView(R.layout.activity_game)
        findViewById<View>(R.id.root).applySystemBarInsets()
        board = findViewById(R.id.board)
        tvTopName = findViewById(R.id.tvTopName)
        tvBottomName = findViewById(R.id.tvBottomName)
        tvTopClock = findViewById(R.id.tvTopClock)
        tvBottomClock = findViewById(R.id.tvBottomClock)
        tvTopCaptured = findViewById(R.id.tvTopCaptured)
        tvBottomCaptured = findViewById(R.id.tvBottomCaptured)
        tvStatus = findViewById(R.id.tvStatus)
        tvDuration = findViewById(R.id.tvDuration)
        tvMoves = findViewById(R.id.tvMoves)
        scrollMoves = findViewById(R.id.scrollMoves)
        btnUndo = findViewById(R.id.btnUndo)
        btnDraw = findViewById(R.id.btnDraw)
        btnResign = findViewById(R.id.btnResign)
        overlay = findViewById(R.id.overlay)
        tvOverlay = findViewById(R.id.tvOverlay)

        board.onSquareClick = { onSquare(it) }
        board.showHints = Prefs.hints(this)
        val t = Prefs.boardTheme(this)
        board.setBoardTheme(BoardThemes.light(t), BoardThemes.dark(t))
        board.flipped = flipped

        btnUndo.setOnClickListener { undo() }
        findViewById<View>(R.id.btnFlip).setOnClickListener {
            flipped = !flipped
            board.flipped = flipped
            refresh()
        }
        btnDraw.setOnClickListener { offerDraw() }
        btnResign.setOnClickListener { confirmResign() }
        findViewById<View>(R.id.btnMore).setOnClickListener { showMoreMenu() }
        findViewById<View>(R.id.btnOverlayExit).setOnClickListener { confirmExit() }
        btnUndo.visibility = if (mode == MODE_ONLINE) View.GONE else View.VISIBLE

        refresh()
        updateOverlay()
    }

    private fun startNewGame(swapColors: Boolean) {
        if (swapColors) myWhite = !myWhite
        game = ChessGame()
        selected = -1
        aiThinking = false
        aiToken++
        gameOverShown = false
        resultRecorded = false
        lastDelta = null
        rematchRequested = false
        myRating = StatsStore.rating(this)
        whiteMs = minutes * 60_000L
        blackMs = minutes * 60_000L
        elapsedMs = 0L
        flipped = if (mode == MODE_LOCAL) false else !myWhite
        board.flipped = flipped
        val now = SystemClock.elapsedRealtime()
        lastTick = now
        lastRx = now
        lastPing = now
        refresh()
        sound.play(Sfx.START)
        if (mode == MODE_AI && !myWhite) runAi()
    }

    // =====================================================================================
    //  JAM, DURASI, DETAK JANTUNG
    // =====================================================================================

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val dt = now - lastTick
            lastTick = now
            if (!game.isOver && !paused) {
                elapsedMs += dt
                if (minutes > 0) {
                    if (game.position.whiteToMove) whiteMs -= dt else blackMs -= dt
                    if (whiteMs <= 0L) {
                        whiteMs = 0L
                        onTimeout(true)
                    } else if (blackMs <= 0L) {
                        blackMs = 0L
                        onTimeout(false)
                    }
                }
                heartbeat(now)
            }
            updateClocks()
            handler.postDelayed(this, 200L)
        }
    }

    private fun heartbeat(now: Long) {
        if (mode != MODE_ONLINE || game.isOver || conn == null) return
        if (now - lastPing >= HEARTBEAT_MS) {
            conn?.send(Protocol.build(Protocol.PING))
            lastPing = now
        }
        if (now - lastRx > DEAD_AFTER_MS) enterPause()
    }

    private fun onTimeout(whiteOut: Boolean) {
        if (game.isOver) return
        game.finish(if (whiteOut) Outcome.BLACK_WIN else Outcome.WHITE_WIN, EndReason.TIMEOUT)
        onGameOver()
    }

    private fun clockText(ms: Long): String {
        if (minutes == 0) return "∞"
        val total = (ms + 999) / 1000
        return String.format(Locale.US, "%d:%02d", total / 60, total % 60)
    }

    private fun updateClocks() {
        val bottomWhite = !flipped
        tvBottomClock.text = clockText(if (bottomWhite) whiteMs else blackMs)
        tvTopClock.text = clockText(if (bottomWhite) blackMs else whiteMs)
        tvDuration.text = getString(R.string.duration_fmt, formatDuration(elapsedMs))
    }

    // =====================================================================================
    //  TAMPILAN
    // =====================================================================================

    private fun refresh() {
        val pos = game.position
        val targets: Set<Int> = if (selected >= 0)
            game.legalMoves().filter { it.from == selected }.map { it.to }.toSet() else emptySet()
        val checkSq = if (pos.inCheck()) pos.kingSquare(pos.whiteToMove) else -1
        board.setState(pos, game.lastMove, checkSq, selected, targets)

        val bottomWhite = !flipped
        tvBottomName.text = label(bottomWhite)
        tvTopName.text = label(!bottomWhite)
        tvBottomCaptured.text = capturedText(bottomWhite)
        tvTopCaptured.text = capturedText(!bottomWhite)

        val active = !game.isOver && !paused
        val whiteActive = active && pos.whiteToMove
        val blackActive = active && !pos.whiteToMove
        tvBottomClock.setBackgroundResource(
            if ((bottomWhite && whiteActive) || (!bottomWhite && blackActive)) R.drawable.bg_clock_active else R.drawable.bg_clock
        )
        tvTopClock.setBackgroundResource(
            if ((!bottomWhite && whiteActive) || (bottomWhite && blackActive)) R.drawable.bg_clock_active else R.drawable.bg_clock
        )
        updateClocks()
        tvStatus.text = statusText()

        val moves = movesText()
        if (tvMoves.text.toString() != moves) {
            tvMoves.text = moves
            scrollMoves.post { scrollMoves.fullScroll(View.FOCUS_DOWN) }
        }
        btnUndo.isEnabled = mode != MODE_ONLINE && !aiThinking && game.moveCount > 0 &&
            !(mode == MODE_AI && resultRecorded)
        btnDraw.isEnabled = !game.isOver && !paused
        btnResign.isEnabled = !game.isOver && !paused
    }

    private fun label(white: Boolean): String {
        if (mode == MODE_LOCAL) return getString(if (white) R.string.player_white else R.string.player_black)
        val color = getString(if (white) R.string.white else R.string.black)
        val mine = white == myWhite
        val name: String
        val rating: Int
        if (mine) {
            name = getString(R.string.you)
            rating = myRating
        } else if (mode == MODE_AI) {
            name = getString(R.string.computer_fmt, level)
            rating = ChessAi.ratingForLevel(level)
        } else {
            name = peerName
            rating = peerRating
        }
        return getString(R.string.name_fmt, name, color, rating)
    }

    /** Bidak yang dimakan pihak [white] + poin material (dan selisihnya bila unggul). */
    private fun capturedText(white: Boolean): String {
        val sb = StringBuilder()
        for (t in game.capturedTypes(white)) sb.append(pieceGlyph(t))
        val mine = game.points(white)
        val theirs = game.points(!white)
        sb.append("  ").append(getString(R.string.points_fmt, mine))
        if (mine > theirs) sb.append(" (+").append(mine - theirs).append(")")
        return sb.toString()
    }

    private fun statusText(): String {
        if (game.isOver) return resultHead() + " · " + reasonText()
        if (paused) return getString(R.string.paused_status)
        if (aiThinking) return getString(R.string.ai_thinking)
        val pos = game.position
        val sb = StringBuilder()
        if (mode == MODE_LOCAL) {
            sb.append(getString(if (pos.whiteToMove) R.string.turn_white else R.string.turn_black))
        } else {
            sb.append(getString(if (pos.whiteToMove == myWhite) R.string.your_turn else R.string.opp_turn))
        }
        if (pos.inCheck()) sb.append(getString(R.string.check_suffix))
        return sb.toString()
    }

    private fun movesText(): String {
        val sb = StringBuilder()
        game.records.forEachIndexed { i, r ->
            if (i % 2 == 0) sb.append(i / 2 + 1).append(". ")
            sb.append(r.san).append(if (i % 2 == 0) " " else "   ")
        }
        return sb.toString()
    }

    private fun updateOverlay() {
        if (!paused) {
            overlay.visibility = View.GONE
            return
        }
        overlay.visibility = View.VISIBLE
        tvOverlay.text = when {
            syncReceived && countdown > 0 -> getString(R.string.resuming_fmt, countdown)
            conn != null -> getString(R.string.syncing)
            else -> getString(R.string.paused_waiting)
        }
    }

    // =====================================================================================
    //  INPUT PEMAIN
    // =====================================================================================

    private fun canMove(): Boolean {
        if (game.isOver || aiThinking || paused) return false
        return mode == MODE_LOCAL || game.position.whiteToMove == myWhite
    }

    private fun onSquare(sq: Int) {
        if (!canMove()) return
        val pos = game.position
        if (selected >= 0) {
            val cands = game.legalMoves().filter { it.from == selected && it.to == sq }
            if (cands.isNotEmpty()) {
                selected = -1
                if (cands.size > 1) askPromotion(cands) else doMove(cands[0], true)
                return
            }
        }
        val p = pos.board[sq]
        selected = if (p != 0 && (p > 0) == pos.whiteToMove && sq != selected) sq else -1
        refresh()
    }

    /** Dialog promosi pion: Ratu / Benteng / Gajah / Kuda. */
    private fun askPromotion(cands: List<Move>) {
        val promos = intArrayOf(QUEEN, ROOK, BISHOP, KNIGHT)
        refresh()
        AlertDialog.Builder(this)
            .setTitle(R.string.promo_title)
            .setItems(R.array.promo_names) { _, i ->
                val m = cands.firstOrNull { it.promo == promos[i] }
                if (m != null) doMove(m, true)
            }
            .setCancelable(false)
            .show()
    }

    /** Menjalankan langkah. [local]=true bila dari pemain di HP ini (akan dikirim ke lawan online). */
    private fun doMove(m: Move, local: Boolean) {
        if (!game.play(m)) return
        selected = -1
        if (local && mode == MODE_ONLINE) conn?.send(Protocol.build(Protocol.MOVE, m.toWire()))
        if (mode == MODE_LOCAL && Prefs.autoFlip(this)) {
            flipped = !game.position.whiteToMove
            board.flipped = flipped
        }
        playMoveSound()
        refresh()
        if (game.isOver) {
            onGameOver()
            return
        }
        if (mode == MODE_AI && game.position.whiteToMove != myWhite) runAi()
    }

    private fun playMoveSound() {
        val r = if (game.records.isEmpty()) return else game.records[game.records.size - 1]
        sound.play(
            when {
                r.givesCheck -> Sfx.CHECK
                r.isPromotion -> Sfx.PROMOTE
                r.isCastle -> Sfx.CASTLE
                r.isCapture -> Sfx.CAPTURE
                else -> Sfx.MOVE
            }
        )
    }

    // =====================================================================================
    //  AI
    // =====================================================================================

    private fun runAi() {
        if (game.isOver || aiThinking) return
        aiThinking = true
        refresh()
        val token = ++aiToken
        val pos = game.position
        val lv = level
        try {
            aiExecutor.execute {
                val m = ChessAi.forLevel(lv).bestMove(pos)
                runOnUiThread {
                    if (token == aiToken && !isFinishing && !isDestroyed) {
                        aiThinking = false
                        if (m != null && !game.isOver) doMove(m, false) else refresh()
                    }
                }
            }
        } catch (e: Exception) {
            aiThinking = false
        }
    }

    private fun undo() {
        if (mode == MODE_ONLINE || aiThinking || game.moveCount == 0) return
        if (mode == MODE_AI && resultRecorded) return   // partai AI yang sudah dinilai tidak bisa di-undo
        if (mode == MODE_AI) {
            // mundur sampai giliran pemain manusia lagi (minimal 1 langkah)
            do {
                game.undo(1)
            } while (game.moveCount > 0 && game.position.whiteToMove != myWhite)
        } else {
            game.undo(1)
        }
        selected = -1
        gameOverShown = false
        resultRecorded = false
        if (mode == MODE_LOCAL && Prefs.autoFlip(this)) {
            flipped = !game.position.whiteToMove
            board.flipped = flipped
        }
        sound.play(Sfx.MOVE)
        refresh()
        if (mode == MODE_AI && game.position.whiteToMove != myWhite) runAi()
    }

    // =====================================================================================
    //  MENYERAH, SERI, KELUAR, MENU
    // =====================================================================================

    private fun confirmResign() {
        if (game.isOver || paused) return
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_resign)
            .setMessage(R.string.confirm_resign)
            .setPositiveButton(R.string.yes) { _, _ ->
                if (game.isOver) return@setPositiveButton
                if (mode == MODE_ONLINE) conn?.send(Protocol.build(Protocol.RESIGN))
                val loserWhite = if (mode == MODE_LOCAL) game.position.whiteToMove else myWhite
                finishGame(if (loserWhite) Outcome.BLACK_WIN else Outcome.WHITE_WIN, EndReason.RESIGNATION)
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    private fun finishGame(o: Outcome, r: EndReason) {
        game.finish(o, r)
        onGameOver()
    }

    private fun offerDraw() {
        if (game.isOver || paused) return
        when (mode) {
            MODE_ONLINE -> {
                conn?.send(Protocol.build(Protocol.DRAW_OFFER))
                toast(R.string.draw_offer_sent)
            }
            MODE_AI -> {
                val stm = ChessAi.evaluate(game.position)
                val whiteScore = if (game.position.whiteToMove) stm else -stm
                val aiScore = if (myWhite) -whiteScore else whiteScore
                if (game.moveCount >= 10 && aiScore <= 0) {
                    finishGame(Outcome.DRAW, EndReason.AGREEMENT)
                } else {
                    toast(R.string.draw_ai_declined)
                }
            }
            else -> AlertDialog.Builder(this)
                .setMessage(R.string.confirm_draw_local)
                .setPositiveButton(R.string.yes) { _, _ -> finishGame(Outcome.DRAW, EndReason.AGREEMENT) }
                .setNegativeButton(R.string.no, null)
                .show()
        }
    }

    private fun confirmExit() {
        val inProgress = !game.isOver && game.moveCount >= 2 && mode != MODE_LOCAL
        AlertDialog.Builder(this)
            .setMessage(if (inProgress) R.string.confirm_exit_loss else R.string.confirm_exit)
            .setPositiveButton(R.string.yes) { _, _ ->
                if (inProgress) {
                    if (mode == MODE_ONLINE && !paused) conn?.send(Protocol.build(Protocol.RESIGN))
                    game.finish(if (myWhite) Outcome.BLACK_WIN else Outcome.WHITE_WIN, EndReason.RESIGNATION)
                    recordResult()
                }
                finish()
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    private fun showMoreMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (mode != MODE_ONLINE) items.add(Pair(getString(R.string.menu_new_game), { confirmNewGame() }))
        items.add(Pair(getString(R.string.menu_copy_pgn), { copyPgn() }))
        if (mode == MODE_ONLINE) items.add(Pair(getString(R.string.menu_chat), { showChat() }))
        items.add(Pair(getString(R.string.menu_exit), { confirmExit() }))
        AlertDialog.Builder(this)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
            .show()
    }

    private fun confirmNewGame() {
        AlertDialog.Builder(this)
            .setMessage(R.string.confirm_new_game)
            .setPositiveButton(R.string.yes) { _, _ ->
                val inProgress = !game.isOver && game.moveCount >= 2 && mode == MODE_AI
                if (inProgress) {
                    game.finish(if (myWhite) Outcome.BLACK_WIN else Outcome.WHITE_WIN, EndReason.RESIGNATION)
                    recordResult()
                }
                startNewGame(false)
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    private fun pgnName(white: Boolean): String = when {
        mode == MODE_LOCAL -> getString(if (white) R.string.white else R.string.black)
        white == myWhite -> Prefs.playerName(this)
        mode == MODE_AI -> getString(R.string.computer_fmt, level)
        else -> peerName
    }

    private fun copyPgn() {
        val pgn = game.toPgn(pgnName(true), pgnName(false))
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("PGN", pgn))
        toast(R.string.pgn_copied)
    }

    private fun showChat() {
        val log = TextView(this)
        log.text = chatLog.toString()
        val sv = ScrollView(this)
        sv.addView(log)
        val input = EditText(this)
        input.setHint(R.string.chat_hint)
        input.maxLines = 2
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(160)))
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_chat)
            .setView(box)
            .setPositiveButton(R.string.send) { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty() && conn != null && !paused) {
                    conn?.send(Protocol.build(Protocol.CHAT, t))
                    chatLog.append(getString(R.string.chat_me, t)).append('\n')
                }
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    // =====================================================================================
    //  AKHIR PARTAI, POIN RATING, HASIL
    // =====================================================================================

    private fun onGameOver() {
        aiToken++
        aiThinking = false
        selected = -1
        refresh()
        handler.postDelayed({ sound.play(Sfx.END) }, 350L)
        recordResult()
        if (gameOverShown) return
        gameOverShown = true
        showResultDialog()
    }

    /** Hitung & simpan poin rating (hanya mode AI/online, minimal 2 langkah dimainkan). */
    private fun recordResult() {
        if (mode == MODE_LOCAL || resultRecorded || !game.isOver) return
        resultRecorded = true
        if (game.moveCount < 2) {
            lastDelta = null
            return
        }
        val score = when (game.outcome) {
            Outcome.DRAW -> 0.5
            Outcome.WHITE_WIN -> if (myWhite) 1.0 else 0.0
            Outcome.BLACK_WIN -> if (myWhite) 0.0 else 1.0
            Outcome.ONGOING -> return
        }
        val oppRating = if (mode == MODE_AI) ChessAi.ratingForLevel(level) else peerRating
        val oppName = if (mode == MODE_AI) getString(R.string.computer_fmt, level) else peerName
        val delta = StatsStore.eloDelta(myRating, oppRating, score)
        val res = if (score > 0.7) 1 else if (score < 0.3) -1 else 0
        ratingBefore = StatsStore.rating(this)
        ratingAfter = StatsStore.record(
            this, GameRecord(System.currentTimeMillis(), mode, oppName, res, delta, elapsedMs, game.moveCount)
        )
        lastDelta = ratingAfter - ratingBefore
    }

    private fun resultHead(): String {
        val res = when (game.outcome) {
            Outcome.WHITE_WIN -> R.string.result_white_win
            Outcome.BLACK_WIN -> R.string.result_black_win
            else -> R.string.result_draw
        }
        if (mode != MODE_LOCAL && game.outcome != Outcome.DRAW) {
            val iWon = (game.outcome == Outcome.WHITE_WIN) == myWhite
            return getString(if (iWon) R.string.result_you_win else R.string.result_you_lose)
        }
        return getString(res)
    }

    private fun reasonText(): String = getString(
        when (game.reason) {
            EndReason.CHECKMATE -> R.string.reason_checkmate
            EndReason.STALEMATE -> R.string.reason_stalemate
            EndReason.FIFTY_MOVE -> R.string.reason_fifty
            EndReason.REPETITION -> R.string.reason_repetition
            EndReason.INSUFFICIENT_MATERIAL -> R.string.reason_insufficient
            EndReason.AGREEMENT -> R.string.reason_agreement
            EndReason.RESIGNATION -> R.string.reason_resign
            EndReason.TIMEOUT -> R.string.reason_timeout
            EndReason.NONE -> R.string.reason_none
        }
    )

    private fun showResultDialog() {
        val sb = StringBuilder()
        sb.append(resultHead()).append("\n").append(reasonText()).append("\n\n")
        sb.append(getString(R.string.over_duration, formatDuration(elapsedMs), game.moveCount)).append("\n")
        sb.append(getString(R.string.over_points, game.points(true), game.points(false)))
        if (mode != MODE_LOCAL) {
            val d = lastDelta
            sb.append("\n")
            if (d != null) {
                val sign = if (d >= 0) "+$d" else "$d"
                sb.append(getString(R.string.over_rating, ratingBefore, ratingAfter, sign))
            } else {
                sb.append(getString(R.string.over_not_rated))
            }
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.over_title)
            .setMessage(sb.toString())
            .setPositiveButton(R.string.play_again) { _, _ ->
                if (mode == MODE_ONLINE) requestRematch() else startNewGame(false)
            }
            .setNeutralButton(R.string.menu_copy_pgn) { _, _ -> copyPgn() }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun requestRematch() {
        val c = conn
        if (c == null || c.closed) {
            toast(R.string.conn_lost_short)
            return
        }
        c.send(Protocol.build(Protocol.REMATCH_REQ, StatsStore.rating(this).toString()))
        rematchRequested = true
        toast(R.string.rematch_wait)
    }

    // =====================================================================================
    //  ONLINE: PESAN MASUK
    // =====================================================================================

    override fun onMessage(line: String) {
        lastRx = SystemClock.elapsedRealtime()
        val (type, a) = Protocol.parse(line)
        when (type) {
            Protocol.MOVE -> {
                val m = a.firstOrNull()?.let { Move.fromWire(it) } ?: return
                if (!game.isOver && game.position.whiteToMove != myWhite) doMove(m, false)
            }
            Protocol.RESIGN -> {
                if (!game.isOver) finishGame(if (myWhite) Outcome.WHITE_WIN else Outcome.BLACK_WIN, EndReason.RESIGNATION)
            }
            Protocol.DRAW_OFFER -> {
                if (game.isOver) return
                AlertDialog.Builder(this)
                    .setMessage(R.string.draw_offer_received)
                    .setPositiveButton(R.string.accept) { _, _ ->
                        if (!game.isOver) {
                            conn?.send(Protocol.build(Protocol.DRAW_ACCEPT))
                            finishGame(Outcome.DRAW, EndReason.AGREEMENT)
                        }
                    }
                    .setNegativeButton(R.string.decline) { _, _ -> conn?.send(Protocol.build(Protocol.DRAW_DECLINE)) }
                    .show()
            }
            Protocol.DRAW_ACCEPT -> {
                if (!game.isOver) finishGame(Outcome.DRAW, EndReason.AGREEMENT)
            }
            Protocol.DRAW_DECLINE -> toast(R.string.draw_declined)
            Protocol.CHAT -> {
                val t = a.firstOrNull() ?: return
                chatLog.append(getString(R.string.chat_peer, peerName, t)).append('\n')
                Toast.makeText(this, getString(R.string.chat_peer, peerName, t), Toast.LENGTH_LONG).show()
            }
            Protocol.REMATCH_REQ -> {
                peerRating = a.firstOrNull()?.toIntOrNull() ?: peerRating
                if (rematchRequested) {
                    conn?.send(Protocol.build(Protocol.REMATCH_OK, StatsStore.rating(this).toString()))
                    startNewGame(true)
                } else {
                    AlertDialog.Builder(this)
                        .setMessage(getString(R.string.rematch_request, peerName))
                        .setPositiveButton(R.string.accept) { _, _ ->
                            conn?.send(Protocol.build(Protocol.REMATCH_OK, StatsStore.rating(this).toString()))
                            startNewGame(true)
                        }
                        .setNegativeButton(R.string.decline, null)
                        .show()
                }
            }
            Protocol.REMATCH_OK -> {
                peerRating = a.firstOrNull()?.toIntOrNull() ?: peerRating
                if (rematchRequested) startNewGame(true)
            }
            Protocol.SYNC -> handleSync(a)
            Protocol.PING -> {}
        }
    }

    override fun onClosed() {
        if (game.isOver) {
            conn = null
            toast(R.string.conn_lost_short)
            return
        }
        enterPause()
    }

    // =====================================================================================
    //  ONLINE: PAUSE, RECONNECT, SINKRON, HITUNG MUNDUR 3 DETIK
    // =====================================================================================

    /** Koneksi putus: jeda permainan (jam berhenti) dan coba menyambung ulang otomatis. */
    private fun enterPause() {
        if (mode != MODE_ONLINE || game.isOver) return
        handler.removeCallbacks(countdownRunnable)
        paused = true
        syncReceived = false
        countdown = 0
        selected = -1
        conn?.setListener(null)
        conn?.close()
        conn = null
        ConnectionHolder.connection = null
        updateOverlay()
        refresh()
        val strategy = ConnectionHolder.reconnect
        if (strategy != null) {
            strategy.stop()
            strategy.start { c -> onReconnected(c) }
        }
    }

    private fun onReconnected(c: GameConnection) {
        if (isDestroyed || isFinishing) {
            c.close()
            return
        }
        conn = c
        ConnectionHolder.connection = c
        lastRx = SystemClock.elapsedRealtime()
        c.setListener(this)
        c.send(syncMessage())
        updateOverlay()
    }

    private fun syncMessage(): String = Protocol.build(
        Protocol.SYNC,
        ConnectionHolder.token,
        game.records.joinToString(";") { it.move.toWire() },
        whiteMs.toString(),
        blackMs.toString()
    )

    private fun handleSync(a: List<String>) {
        if (!paused) return
        if ((a.getOrNull(0) ?: "") != ConnectionHolder.token) {
            enterPause()   // bukan lawan yang sama: tutup & tunggu lagi
            return
        }
        val theirs = (a.getOrNull(1) ?: "").split(";").filter { it.isNotEmpty() }.mapNotNull { Move.fromWire(it) }
        val mine = game.records.map { it.move }
        if (theirs.size > mine.size && theirs.subList(0, mine.size) == mine) {
            for (m in theirs.drop(mine.size)) {
                if (!game.play(m)) break
            }
        }
        if (!ConnectionHolder.isHost) {
            whiteMs = a.getOrNull(2)?.toLongOrNull() ?: whiteMs
            blackMs = a.getOrNull(3)?.toLongOrNull() ?: blackMs
        }
        syncReceived = true
        refresh()
        if (game.isOver) {
            paused = false
            updateOverlay()
            onGameOver()
            return
        }
        countdown = 3
        updateOverlay()
        handler.removeCallbacks(countdownRunnable)
        handler.postDelayed(countdownRunnable, 1000L)
    }

    private val countdownRunnable = object : Runnable {
        override fun run() {
            if (!paused || !syncReceived) return
            countdown--
            if (countdown <= 0) {
                resumeGame()
            } else {
                updateOverlay()
                handler.postDelayed(this, 1000L)
            }
        }
    }

    private fun resumeGame() {
        paused = false
        syncReceived = false
        val now = SystemClock.elapsedRealtime()
        lastTick = now
        lastRx = now
        lastPing = now
        updateOverlay()
        refresh()
        toast(R.string.resumed)
        sound.play(Sfx.START)
    }

    // =====================================================================================

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
