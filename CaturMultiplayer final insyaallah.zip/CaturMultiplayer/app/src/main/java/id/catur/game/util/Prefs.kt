package id.catur.game.util

import android.content.Context
import android.content.SharedPreferences
import android.os.Build

/*
 * FILE: Prefs.kt  (folder util/)
 * Fungsi: penyimpanan pengaturan pemain (SharedPreferences): tema papan, petunjuk langkah,
 * efek suara, putar papan otomatis (mode 2 pemain), dan nama pemain.
 */
object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("catur_prefs", Context.MODE_PRIVATE)

    fun boardTheme(c: Context): Int = sp(c).getInt("theme", 0)
    fun setBoardTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun hints(c: Context): Boolean = sp(c).getBoolean("hints", true)
    fun setHints(c: Context, v: Boolean) = sp(c).edit().putBoolean("hints", v).apply()

    fun sound(c: Context): Boolean = sp(c).getBoolean("sound", true)
    fun setSound(c: Context, v: Boolean) = sp(c).edit().putBoolean("sound", v).apply()

    fun autoFlip(c: Context): Boolean = sp(c).getBoolean("auto_flip", false)
    fun setAutoFlip(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_flip", v).apply()

    fun playerName(c: Context): String {
        val n = sp(c).getString("name", null)
        return if (n.isNullOrBlank()) Build.MODEL.ifBlank { "Pemain" } else n
    }

    fun setPlayerName(c: Context, v: String) = sp(c).edit().putString("name", v.trim()).apply()
}
