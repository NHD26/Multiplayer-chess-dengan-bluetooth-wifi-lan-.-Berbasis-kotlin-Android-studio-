package id.catur.game.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import id.catur.game.engine.Move
import id.catur.game.engine.Position
import id.catur.game.engine.pieceGlyph
import kotlin.math.abs
import kotlin.math.min

/*
 * FILE: ChessBoardView.kt  (folder ui/)
 * Fungsi: komponen papan catur (custom View, digambar dengan Canvas).
 *  - selalu persegi: lebar mengikuti layar saat portrait, tinggi saat landscape
 *  - menggambar petak, koordinat, bidak, sorotan langkah terakhir, petak terpilih,
 *    raja yang sedang skak (merah), titik langkah legal / cincin untuk tangkapan
 *  - mendukung papan dibalik (flipped) untuk pemain Hitam
 * Komponen ini hanya MENAMPILKAN; semua aturan ada di paket engine.
 */
class ChessBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var onSquareClick: ((Int) -> Unit)? = null
    var showHints: Boolean = true
    var flipped: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private var position: Position? = null
    private var lastFrom = -1
    private var lastTo = -1
    private var checkSquare = -1
    private var selected = -1
    private var targets: Set<Int> = emptySet()
    private var lightColor = 0xFFEEEED2.toInt()
    private var darkColor = 0xFF769656.toInt()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val coord = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFakeBoldText = true }
    private val pieceFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val pieceStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        style = Paint.Style.STROKE
    }

    fun setBoardTheme(light: Int, dark: Int) {
        lightColor = light
        darkColor = dark
        invalidate()
    }

    fun setState(position: Position, last: Move?, checkSquare: Int, selected: Int, targets: Set<Int>) {
        this.position = position
        this.lastFrom = last?.from ?: -1
        this.lastTo = last?.to ?: -1
        this.checkSquare = checkSquare
        this.selected = selected
        this.targets = targets
        invalidate()
    }

    private fun toSquare(row: Int, col: Int): Int =
        if (!flipped) row * 8 + col else (7 - row) * 8 + (7 - col)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val wm = MeasureSpec.getMode(widthMeasureSpec)
        val hm = MeasureSpec.getMode(heightMeasureSpec)
        val size = when {
            wm == MeasureSpec.EXACTLY && hm == MeasureSpec.UNSPECIFIED -> w
            hm == MeasureSpec.EXACTLY && wm != MeasureSpec.EXACTLY -> h
            hm == MeasureSpec.UNSPECIFIED -> w
            wm == MeasureSpec.UNSPECIFIED -> h
            else -> min(w, h)
        }
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        val pos = position ?: return
        val cell = width / 8f
        pieceFill.textSize = cell * 0.82f
        pieceStroke.textSize = cell * 0.82f
        pieceStroke.strokeWidth = cell * 0.035f
        coord.textSize = cell * 0.18f
        ring.strokeWidth = cell * 0.07f
        val fm = pieceFill.fontMetrics
        val textOffset = -(fm.ascent + fm.descent) / 2f

        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val sq = toSquare(row, col)
                val left = col * cell
                val top = row * cell
                val light = (row + col) % 2 == 0
                fill.color = if (light) lightColor else darkColor
                canvas.drawRect(left, top, left + cell, top + cell, fill)

                if (sq == lastFrom || sq == lastTo) {
                    fill.color = 0x66F6F669
                    canvas.drawRect(left, top, left + cell, top + cell, fill)
                }
                if (sq == selected) {
                    fill.color = 0x8814C814.toInt()
                    canvas.drawRect(left, top, left + cell, top + cell, fill)
                }
                if (sq == checkSquare) {
                    fill.color = 0x99FF2020.toInt()
                    canvas.drawCircle(left + cell / 2, top + cell / 2, cell * 0.46f, fill)
                }

                coord.color = if (light) darkColor else lightColor
                if (col == 0) {
                    coord.textAlign = Paint.Align.LEFT
                    canvas.drawText(('8' - sq / 8).toString(), left + cell * 0.05f, top + cell * 0.2f, coord)
                }
                if (row == 7) {
                    coord.textAlign = Paint.Align.RIGHT
                    canvas.drawText(('a' + sq % 8).toString(), left + cell * 0.95f, top + cell * 0.95f, coord)
                }

                val p = pos.board[sq]
                if (p != 0) {
                    val glyph = pieceGlyph(abs(p))
                    val cx = left + cell / 2
                    val by = top + cell / 2 + textOffset
                    if (p > 0) {
                        pieceStroke.color = 0xFF202020.toInt()
                        pieceFill.color = 0xFFFFFFFF.toInt()
                    } else {
                        pieceStroke.color = 0xFFE8E8E8.toInt()
                        pieceFill.color = 0xFF1C1C1C.toInt()
                    }
                    canvas.drawText(glyph, cx, by, pieceStroke)
                    canvas.drawText(glyph, cx, by, pieceFill)
                }

                if (showHints && sq in targets) {
                    if (p != 0) {
                        ring.color = 0x88202020.toInt()
                        canvas.drawCircle(left + cell / 2, top + cell / 2, cell * 0.46f, ring)
                    } else {
                        fill.color = 0x66202020
                        canvas.drawCircle(left + cell / 2, top + cell / 2, cell * 0.16f, fill)
                    }
                }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val cell = width / 8f
                val col = (e.x / cell).toInt().coerceIn(0, 7)
                val row = (e.y / cell).toInt().coerceIn(0, 7)
                performClick()
                onSquareClick?.invoke(toSquare(row, col))
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
