package id.catur.game.util

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import id.catur.game.R
import java.util.concurrent.ConcurrentHashMap

enum class Sfx { MOVE, CAPTURE, CHECK, CASTLE, PROMOTE, END, START }

/*
 * FILE: SoundManager.kt  (folder util/)
 * Fungsi: memutar efek suara catur (langkah, makan, skak, rokade, promosi, game selesai, mulai)
 * dari file res/raw/sfx_*.wav memakai SoundPool (latensi rendah). Bisa dimatikan di Pengaturan.
 */
class SoundManager(context: Context) {
    private val pool: SoundPool
    private val ids = HashMap<Sfx, Int>()
    private val ready: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    var enabled: Boolean = true

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        pool.setOnLoadCompleteListener { _, id, status -> if (status == 0) ready.add(id) }
        ids[Sfx.MOVE] = pool.load(context, R.raw.sfx_move, 1)
        ids[Sfx.CAPTURE] = pool.load(context, R.raw.sfx_capture, 1)
        ids[Sfx.CHECK] = pool.load(context, R.raw.sfx_check, 1)
        ids[Sfx.CASTLE] = pool.load(context, R.raw.sfx_castle, 1)
        ids[Sfx.PROMOTE] = pool.load(context, R.raw.sfx_promote, 1)
        ids[Sfx.END] = pool.load(context, R.raw.sfx_end, 1)
        ids[Sfx.START] = pool.load(context, R.raw.sfx_start, 1)
    }

    fun play(s: Sfx) {
        if (!enabled) return
        val id = ids[s] ?: return
        if (id in ready) pool.play(id, 1f, 1f, 1, 0, 1f)
    }

    fun release() {
        pool.release()
    }
}
