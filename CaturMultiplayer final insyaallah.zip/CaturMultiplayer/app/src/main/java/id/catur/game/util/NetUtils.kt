package id.catur.game.util

import android.content.Context
import android.net.wifi.WifiManager
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

/*
 * FILE: NetUtils.kt  (folder util/)
 * Fungsi: helper jaringan: daftar IP lokal HP ini (untuk ditampilkan oleh Host)
 * dan IP gateway WiFi (otomatis = IP HP pemilik hotspot, dipakai sebagai tebakan IP host).
 */
object NetUtils {
    fun localIpv4(): List<String> {
        return try {
            val out = ArrayList<String>()
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (addr in Collections.list(ni.inetAddresses)) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val h = addr.hostAddress
                        if (!h.isNullOrEmpty()) out.add(h)
                    }
                }
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Suppress("DEPRECATION")
    fun gatewayIp(ctx: Context): String? {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null
        val gw = wm.dhcpInfo?.gateway ?: 0
        if (gw == 0) return null
        return "${gw and 0xFF}.${(gw shr 8) and 0xFF}.${(gw shr 16) and 0xFF}.${(gw shr 24) and 0xFF}"
    }
}
