package id.catur.game.util

/*
 * FILE: BoardThemes.kt  (folder util/)
 * Fungsi: daftar warna papan (petak terang & gelap). Urutan sama dengan array theme_names
 * di res/values/arrays.xml.
 */
object BoardThemes {
    private val lights = intArrayOf(0xFFEEEED2.toInt(), 0xFFF0D9B5.toInt(), 0xFFDEE3E6.toInt(), 0xFFE0E0E0.toInt())
    private val darks = intArrayOf(0xFF769656.toInt(), 0xFFB58863.toInt(), 0xFF8CA2AD.toInt(), 0xFF9E9E9E.toInt())

    fun light(i: Int): Int = lights[i.coerceIn(0, lights.size - 1)]
    fun dark(i: Int): Int = darks[i.coerceIn(0, darks.size - 1)]
}
