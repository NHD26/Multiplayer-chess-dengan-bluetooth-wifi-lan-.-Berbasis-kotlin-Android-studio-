package id.catur.game.network

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.os.Handler
import android.os.Looper
import java.io.IOException

/*
 * FILE: BluetoothConnector.kt  (folder network/)
 * Fungsi: koneksi via Bluetooth klasik (RFCOMM, UUID di Protocol.BT_UUID).
 *  - BluetoothHost  : membuka server RFCOMM dan menunggu lawan.
 *  - BluetoothClient: menyambung ke perangkat lawan yang dipilih.
 * Izin runtime (BLUETOOTH_CONNECT/SCAN/ADVERTISE) diminta di BluetoothLobbyActivity.
 */
@SuppressLint("MissingPermission")
class BluetoothHost(
    private val adapter: BluetoothAdapter,
    private val callback: (GameConnection?, String?) -> Unit
) : Cancelable {
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var server: BluetoothServerSocket? = null

    @Volatile
    private var cancelled = false

    fun start() {
        Thread({
            try {
                val ss = adapter.listenUsingRfcommWithServiceRecord("CaturMultiplayer", Protocol.BT_UUID)
                server = ss
                if (cancelled) {
                    ss.close()
                } else {
                    val s = ss.accept()
                    ss.close()
                    val c = StreamConnection(s.inputStream, s.outputStream) { s.close() }
                    c.start()
                    main.post { callback(c, null) }
                }
            } catch (e: IOException) {
                if (!cancelled) main.post { callback(null, e.message) }
            }
        }, "catur-bt-host").start()
    }

    override fun cancel() {
        cancelled = true
        try {
            server?.close()
        } catch (e: IOException) {
            // abaikan
        }
    }
}

@SuppressLint("MissingPermission")
class BluetoothClient(private val adapter: BluetoothAdapter) {
    private val main = Handler(Looper.getMainLooper())

    fun connect(device: BluetoothDevice, callback: (GameConnection?, String?) -> Unit) {
        Thread({
            try {
                adapter.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(Protocol.BT_UUID)
                s.connect()
                val c = StreamConnection(s.inputStream, s.outputStream) { s.close() }
                c.start()
                main.post { callback(c, null) }
            } catch (e: Exception) {
                main.post { callback(null, e.message) }
            }
        }, "catur-bt-client").start()
    }
}
