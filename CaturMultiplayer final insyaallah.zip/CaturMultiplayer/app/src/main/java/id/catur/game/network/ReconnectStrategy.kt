package id.catur.game.network

import android.os.Handler
import android.os.Looper

/*
 * FILE: ReconnectStrategy.kt  (folder network/)
 * Fungsi: cara menyambung ULANG saat koneksi terputus di tengah partai.
 *  - HostReconnect  : host membuka kembali server dan menunggu lawan (WiFi atau Bluetooth).
 *  - ClientReconnect: klien mencoba menyambung ke host tiap 2 detik sampai berhasil.
 * Setelah tersambung, GameActivity menjalankan sinkronisasi + hitung mundur 3 detik.
 */
interface ReconnectStrategy {
    fun start(onConnected: (GameConnection) -> Unit)
    fun stop()
}

class HostReconnect(
    private val listen: ((GameConnection?, String?) -> Unit) -> Cancelable
) : ReconnectStrategy {
    private val main = Handler(Looper.getMainLooper())
    private var active = false
    private var current: Cancelable? = null

    override fun start(onConnected: (GameConnection) -> Unit) {
        active = true
        open(onConnected)
    }

    private fun open(onConnected: (GameConnection) -> Unit) {
        if (!active) return
        current = listen { conn, _ ->
            if (!active) {
                conn?.close()
            } else if (conn != null) {
                active = false
                onConnected(conn)
            } else {
                main.postDelayed({ open(onConnected) }, 2000L)
            }
        }
    }

    override fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
        current?.cancel()
        current = null
    }
}

class ClientReconnect(
    private val connect: ((GameConnection?, String?) -> Unit) -> Unit
) : ReconnectStrategy {
    private val main = Handler(Looper.getMainLooper())
    private var active = false

    override fun start(onConnected: (GameConnection) -> Unit) {
        active = true
        attempt(onConnected)
    }

    private fun attempt(onConnected: (GameConnection) -> Unit) {
        if (!active) return
        connect { conn, _ ->
            if (!active) {
                conn?.close()
            } else if (conn != null) {
                active = false
                onConnected(conn)
            } else {
                main.postDelayed({ attempt(onConnected) }, 2000L)
            }
        }
    }

    override fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
    }
}
