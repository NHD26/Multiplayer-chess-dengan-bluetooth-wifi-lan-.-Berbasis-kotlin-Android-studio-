package id.catur.game.engine

import kotlin.math.abs
import kotlin.random.Random

/*
 * FILE: ChessAi.kt  (folder engine/)
 * Fungsi: lawan komputer MODEL RINGAN (tanpa library eksternal / tanpa file model):
 *   negamax + alpha-beta + iterative deepening + pencarian tangkapan singkat (quiescence),
 *   evaluasi = nilai material + bonus posisi sederhana. Kedalaman dan waktu berpikir dibatasi
 *   sehingga hemat baterai & tetap lancar di HP kelas bawah.
 *   Level 1: kedalaman 1, kadang sengaja salah langkah (pemula)
 *   Level 2: kedalaman 2 | Level 3: kedalaman 3 | Level 4: kedalaman 4 (maks 1,5 detik)
 */
class ChessAi(
    private val maxDepth: Int,
    private val timeLimitMs: Long,
    private val blunderChance: Double = 0.0
) {
    companion object {
        private const val INF = 1_000_000
        private const val MATE = 100_000
        private val VALUE = intArrayOf(0, 100, 320, 330, 500, 900, 0)

        fun forLevel(level: Int): ChessAi = when (level) {
            1 -> ChessAi(1, 300L, 0.30)
            2 -> ChessAi(2, 800L)
            3 -> ChessAi(3, 1200L)
            else -> ChessAi(4, 1500L)
        }

        /** Perkiraan rating tiap level (dipakai untuk menghitung poin rating ala chess.com). */
        fun ratingForLevel(level: Int): Int = when (level) {
            1 -> 400
            2 -> 800
            3 -> 1200
            else -> 1600
        }

        /** Evaluasi dari sudut pandang pihak yang sedang jalan (positif = menguntungkan). */
        fun evaluate(pos: Position): Int {
            var mat = 0
            for (sq in 0 until 64) {
                val t = abs(pos.board[sq])
                if (t != 0 && t != PAWN && t != KING) mat += VALUE[t]
            }
            val endgame = mat < 2600
            var score = 0
            for (sq in 0 until 64) {
                val p = pos.board[sq]
                if (p == 0) continue
                val t = abs(p)
                val white = p > 0
                val r = sq / 8
                val c = sq % 8
                val cd = abs(2 * c - 7) + abs(2 * r - 7)          // jarak ke tengah: 2..14
                val home = if (white) 7 - r else r                // 0 = baris asal
                var v = VALUE[t]
                when (t) {
                    PAWN -> {
                        val adv = if (white) 6 - r else r - 1
                        v += adv * 8 + (if (c == 3 || c == 4) adv * 4 else 0)
                    }
                    KNIGHT -> v += 28 - cd * 4
                    BISHOP -> v += 14 - cd * 2
                    ROOK -> if (home == 6) v += 15
                    KING -> v += if (endgame) 20 - cd * 3
                    else if (home == 0) 10 + (if (c == 6 || c == 2) 25 else 0) else -home * 12
                }
                score += if (white) v else -v
            }
            return if (pos.whiteToMove) score else -score
        }
    }

    private var deadline = 0L
    private var aborted = false
    private var nodes = 0

    /** Mencari langkah terbaik (null bila tidak ada langkah legal). Jalankan di thread latar! */
    fun bestMove(pos: Position): Move? {
        val legal = pos.legalMoves()
        if (legal.isEmpty()) return null
        if (legal.size == 1) return legal[0]
        if (blunderChance > 0.0 && Random.nextDouble() < blunderChance) return legal.random()

        deadline = System.currentTimeMillis() + timeLimitMs
        aborted = false
        nodes = 0
        var ordered = orderMoves(pos, legal)
        var best = ordered[0]
        for (depth in 1..maxDepth) {
            var alpha = -INF
            var bestThis: Move? = null
            var bestScore = -INF
            for (m in ordered) {
                val s = -search(pos.apply(m), depth - 1, -INF, -alpha, 1)
                if (aborted) break
                if (s > bestScore) {
                    bestScore = s
                    bestThis = m
                }
                if (s > alpha) alpha = s
            }
            if (aborted || bestThis == null) break
            best = bestThis
            ordered = listOf(best) + ordered.filter { it != best }
            if (abs(bestScore) > MATE - 100) break
        }
        return best
    }

    private fun search(pos: Position, depth: Int, alphaIn: Int, beta: Int, ply: Int): Int {
        nodes++
        if ((nodes and 255) == 0 && System.currentTimeMillis() > deadline) aborted = true
        if (aborted) return 0
        if (depth <= 0) return quiesce(pos, alphaIn, beta, 0)
        val moves = pos.legalMoves()
        if (moves.isEmpty()) return if (pos.inCheck()) -MATE + ply else 0
        if (pos.halfmoveClock >= 100) return 0
        var alpha = alphaIn
        for (m in orderMoves(pos, moves)) {
            val s = -search(pos.apply(m), depth - 1, -beta, -alpha, ply + 1)
            if (aborted) return 0
            if (s >= beta) return beta
            if (s > alpha) alpha = s
        }
        return alpha
    }

    private fun quiesce(pos: Position, alphaIn: Int, beta: Int, qd: Int): Int {
        val stand = evaluate(pos)
        if (stand >= beta) return beta
        var alpha = if (stand > alphaIn) stand else alphaIn
        if (qd >= 3) return alpha
        val caps = pos.legalMoves().filter { pos.board[it.to] != 0 || it.promo != 0 }
        for (m in orderMoves(pos, caps)) {
            val s = -quiesce(pos.apply(m), -beta, -alpha, qd + 1)
            if (aborted) return 0
            if (s >= beta) return beta
            if (s > alpha) alpha = s
        }
        return alpha
    }

    private fun orderMoves(pos: Position, moves: List<Move>): List<Move> =
        moves.sortedByDescending { m ->
            val victim = abs(pos.board[m.to])
            val attacker = abs(pos.board[m.from])
            var s = if (victim != 0) 10 * VALUE[victim] - VALUE[attacker] / 10 else 0
            if (m.promo != 0) s += VALUE[m.promo]
            s
        }
}
