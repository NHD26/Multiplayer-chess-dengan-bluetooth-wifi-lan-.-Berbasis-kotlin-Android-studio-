package id.catur.game.network

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/*
 * FILE: StreamConnection.kt  (folder network/)
 * Fungsi: koneksi berbasis stream (dipakai WiFi Socket & BluetoothSocket).
 * Membaca pesan per baris di thread latar dan menulis lewat antrean 1 thread
 * (supaya tidak melanggar aturan "NetworkOnMainThread").
 */
class StreamConnection(
    private val input: InputStream,
    private val output: OutputStream,
    private val closeAction: () -> Unit
) : GameConnection() {

    private val writer: ExecutorService = Executors.newSingleThreadExecutor()

    fun start() {
        Thread({
            try {
                val reader = BufferedReader(InputStreamReader(input, Charsets.UTF_8))
                while (true) {
                    val line = reader.readLine() ?: break
                    deliver(line)
                }
            } catch (e: IOException) {
                // koneksi putus: ditangani di bawah
            }
            terminate(true)
        }, "catur-net-reader").start()
    }

    override fun send(line: String) {
        if (closed) return
        try {
            writer.execute {
                try {
                    output.write((line + "\n").toByteArray(Charsets.UTF_8))
                    output.flush()
                } catch (e: IOException) {
                    terminate(true)
                }
            }
        } catch (e: Exception) {
            // executor sudah ditutup
        }
    }

    @Synchronized
    private fun terminate(notify: Boolean) {
        if (closed) return
        closed = true
        try {
            closeAction()
        } catch (e: Exception) {
            // abaikan
        }
        writer.shutdown()
        if (notify) deliverClosed()
    }

    override fun close() {
        if (!closed) {
            // beri kesempatan pesan terakhir di antrean (mis. RESIGN) terkirim dulu
            writer.shutdown()
            try {
                writer.awaitTermination(400, TimeUnit.MILLISECONDS)
            } catch (e: InterruptedException) {
                // abaikan
            }
        }
        terminate(false)
    }
}
