package id.catur.game.network

/*
 * FILE: ConnectionHolder.kt  (folder network/)
 * Fungsi: tempat penitipan koneksi aktif supaya bisa diserahkan dari layar Lobi ke layar Game
 * (objek koneksi tidak bisa dikirim lewat Intent). Juga menyimpan info sesi online.
 */
object ConnectionHolder {
    var connection: GameConnection? = null
    var isHost: Boolean = false
    var token: String = ""
    var reconnect: ReconnectStrategy? = null

    fun begin(conn: GameConnection, host: Boolean, token: String, strategy: ReconnectStrategy) {
        connection = conn
        isHost = host
        this.token = token
        reconnect = strategy
    }

    fun clear() {
        reconnect?.stop()
        reconnect = null
        connection = null
        token = ""
    }
}
