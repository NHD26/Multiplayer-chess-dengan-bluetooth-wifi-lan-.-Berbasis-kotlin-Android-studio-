package id.catur.game

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import id.catur.game.engine.Position
import id.catur.game.ui.ChessBoardView
import id.catur.game.util.BoardThemes
import id.catur.game.util.Prefs
import id.catur.game.util.applySystemBarInsets

/*
 * FILE: SettingsActivity.kt  (folder id/catur/game/)
 * Fungsi: layar PENGATURAN: nama pemain, tema papan (ada pratinjau), petunjuk langkah legal,
 * efek suara, putar papan otomatis (mode 2 pemain). Tersimpan otomatis.
 */
class SettingsActivity : AppCompatActivity() {
    private lateinit var preview: ChessBoardView
    private lateinit var etName: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.root).applySystemBarInsets()

        preview = findViewById(R.id.preview)
        preview.setState(Position.initial(), null, -1, -1, emptySet())
        etName = findViewById(R.id.etName)
        etName.setText(Prefs.playerName(this))

        val sp = findViewById<Spinner>(R.id.spTheme)
        sp.setSelection(Prefs.boardTheme(this))
        applyTheme(Prefs.boardTheme(this))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Prefs.setBoardTheme(this@SettingsActivity, position)
                applyTheme(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        findViewById<CheckBox>(R.id.cbHints).apply {
            isChecked = Prefs.hints(this@SettingsActivity)
            setOnCheckedChangeListener { _, c -> Prefs.setHints(this@SettingsActivity, c) }
        }
        findViewById<CheckBox>(R.id.cbSound).apply {
            isChecked = Prefs.sound(this@SettingsActivity)
            setOnCheckedChangeListener { _, c -> Prefs.setSound(this@SettingsActivity, c) }
        }
        findViewById<CheckBox>(R.id.cbAutoFlip).apply {
            isChecked = Prefs.autoFlip(this@SettingsActivity)
            setOnCheckedChangeListener { _, c -> Prefs.setAutoFlip(this@SettingsActivity, c) }
        }
    }

    private fun applyTheme(i: Int) {
        preview.setBoardTheme(BoardThemes.light(i), BoardThemes.dark(i))
    }

    override fun onPause() {
        super.onPause()
        Prefs.setPlayerName(this, etName.text.toString())
    }
}
