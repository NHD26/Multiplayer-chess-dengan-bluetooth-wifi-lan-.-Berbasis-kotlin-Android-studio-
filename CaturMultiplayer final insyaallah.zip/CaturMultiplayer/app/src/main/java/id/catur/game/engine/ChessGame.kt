package id.catur.game.engine

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/*
 * FILE: ChessGame.kt  (folder engine/)
 * Fungsi: status satu partai catur: riwayat posisi & langkah, notasi SAN, undo, hasil akhir.
 * Mendeteksi otomatis: SKAKMAT, STALEMATE (remis), remis 50 langkah, remis pengulangan 3x,
 * remis material tidak cukup. Juga mendukung hasil manual: menyerah, waktu habis, sepakat remis.
 */

enum class Outcome { ONGOING, WHITE_WIN, BLACK_WIN, DRAW }

enum class EndReason {
    NONE, CHECKMATE, STALEMATE, FIFTY_MOVE, REPETITION, INSUFFICIENT_MATERIAL, AGREEMENT, RESIGNATION, TIMEOUT
}

/** Catatan satu langkah yang sudah dimainkan. */
class MoveRecord(
    val move: Move,
    val san: String,
    val movedPiece: Int,
    val captured: Int,
    val isCastle: Boolean,
    val givesCheck: Boolean
) {
    val isCapture: Boolean get() = captured != 0
    val isPromotion: Boolean get() = move.promo != 0
}

class ChessGame(start: Position = Position.initial()) {
    private val positions = ArrayList<Position>()
    val records = ArrayList<MoveRecord>()
    var outcome: Outcome = Outcome.ONGOING
        private set
    var reason: EndReason = EndReason.NONE
        private set
    private var cachedLegal: List<Move>? = null

    init {
        positions.add(start)
    }

    val position: Position get() = positions[positions.size - 1]
    val isOver: Boolean get() = outcome != Outcome.ONGOING
    val moveCount: Int get() = records.size
    val lastMove: Move? get() = if (records.isEmpty()) null else records[records.size - 1].move

    /** Semua langkah legal untuk posisi sekarang (di-cache). */
    fun legalMoves(): List<Move> {
        val c = cachedLegal
        if (c != null) return c
        val l = position.legalMoves()
        cachedLegal = l
        return l
    }

    /** Memainkan [m] bila legal. Mengembalikan false bila ilegal / permainan sudah selesai. */
    fun play(m: Move): Boolean {
        if (isOver) return false
        val legal = legalMoves()
        if (m !in legal) return false
        val pos = position
        val piece = pos.board[m.from]
        val isEp = abs(piece) == PAWN && pos.board[m.to] == 0 && m.from % 8 != m.to % 8
        val captured = if (isEp) (if (piece > 0) -PAWN else PAWN) else pos.board[m.to]
        val isCastle = abs(piece) == KING && abs(m.to - m.from) == 2
        val next = pos.apply(m)
        val nextLegal = next.legalMoves()
        val check = next.inCheck()
        var san = sanBase(pos, m, legal)
        if (check) san += if (nextLegal.isEmpty()) "#" else "+"
        positions.add(next)
        records.add(MoveRecord(m, san, piece, captured, isCastle, check))
        cachedLegal = nextLegal
        evaluateEnd(next, nextLegal)
        return true
    }

    private fun evaluateEnd(next: Position, nextLegal: List<Move>) {
        if (nextLegal.isEmpty()) {
            if (next.inCheck()) {
                finish(if (next.whiteToMove) Outcome.BLACK_WIN else Outcome.WHITE_WIN, EndReason.CHECKMATE)
            } else {
                finish(Outcome.DRAW, EndReason.STALEMATE)
            }
            return
        }
        if (insufficientMaterial(next)) {
            finish(Outcome.DRAW, EndReason.INSUFFICIENT_MATERIAL)
        } else if (next.halfmoveClock >= 100) {
            finish(Outcome.DRAW, EndReason.FIFTY_MOVE)
        } else {
            val key = next.key()
            if (positions.count { it.key() == key } >= 3) finish(Outcome.DRAW, EndReason.REPETITION)
        }
    }

    /** Mengakhiri permainan secara manual (menyerah, waktu habis, sepakat remis). */
    fun finish(o: Outcome, r: EndReason) {
        outcome = o
        reason = r
    }

    /** Membatalkan [n] langkah terakhir. */
    fun undo(n: Int = 1) {
        var k = n
        while (k > 0 && records.isNotEmpty()) {
            positions.removeAt(positions.size - 1)
            records.removeAt(records.size - 1)
            k--
        }
        cachedLegal = null
        outcome = Outcome.ONGOING
        reason = EndReason.NONE
    }

    private fun insufficientMaterial(pos: Position): Boolean {
        var minors = 0
        var onlyBishops = true
        val bishopColors = HashSet<Int>()
        for (sq in 0 until 64) {
            val t = abs(pos.board[sq])
            if (t == 0 || t == KING) continue
            if (t == PAWN || t == ROOK || t == QUEEN) return false
            minors++
            if (t == BISHOP) bishopColors.add((sq / 8 + sq % 8) % 2) else onlyBishops = false
        }
        if (minors <= 1) return true
        return onlyBishops && bishopColors.size == 1
    }

    // ------------------------------------------------------------------ notasi & statistik

    private fun sanBase(pos: Position, m: Move, legal: List<Move>): String {
        val p = pos.board[m.from]
        val t = abs(p)
        val isCapture = pos.board[m.to] != 0 || (t == PAWN && m.from % 8 != m.to % 8)
        if (t == KING && abs(m.to - m.from) == 2) return if (m.to > m.from) "O-O" else "O-O-O"
        val from = Move.squareName(m.from)
        val sb = StringBuilder()
        if (t == PAWN) {
            if (isCapture) sb.append(from[0])
        } else {
            sb.append("PNBRQK"[t - 1])
            val others = legal.filter { it.from != m.from && pos.board[it.from] == p && it.to == m.to }
            if (others.isNotEmpty()) {
                val sameFile = others.any { it.from % 8 == m.from % 8 }
                val sameRank = others.any { it.from / 8 == m.from / 8 }
                if (!sameFile) sb.append(from[0]) else if (!sameRank) sb.append(from[1]) else sb.append(from)
            }
        }
        if (isCapture) sb.append('x')
        sb.append(Move.squareName(m.to))
        if (m.promo != 0) sb.append('=').append("PNBRQK"[m.promo - 1])
        return sb.toString()
    }

    /** Jenis bidak yang sudah dimakan oleh pihak [byWhite], urut dari paling bernilai. */
    fun capturedTypes(byWhite: Boolean): List<Int> =
        records.filter { if (byWhite) it.captured < 0 else it.captured > 0 }
            .map { abs(it.captured) }
            .sortedDescending()

    /** Total poin material yang diperoleh pihak [byWhite] dari bidak yang dimakan. */
    fun points(byWhite: Boolean): Int = capturedTypes(byWhite).sumOf { piecePoints(it) }

    fun toPgn(whiteName: String, blackName: String): String {
        val result = when (outcome) {
            Outcome.WHITE_WIN -> "1-0"
            Outcome.BLACK_WIN -> "0-1"
            Outcome.DRAW -> "1/2-1/2"
            Outcome.ONGOING -> "*"
        }
        val date = SimpleDateFormat("yyyy.MM.dd", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.append("[Event \"Catur Multiplayer\"]\n[Site \"Android\"]\n[Date \"").append(date).append("\"]\n")
        sb.append("[White \"").append(whiteName).append("\"]\n[Black \"").append(blackName).append("\"]\n")
        sb.append("[Result \"").append(result).append("\"]\n\n")
        records.forEachIndexed { i, r ->
            if (i % 2 == 0) sb.append(i / 2 + 1).append(". ")
            sb.append(r.san).append(' ')
        }
        sb.append(result)
        return sb.toString()
    }
}
