package id.catur.game.util

import android.view.View
import android.widget.Spinner
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import id.catur.game.R
import java.util.Locale
import kotlin.random.Random

/*
 * FILE: UiUtils.kt  (folder util/)
 * Fungsi: helper tampilan.
 *  - applySystemBarInsets(): beri padding agar konten tidak tertutup status bar / navigation bar
 *    (wajib di Android 15 yang selalu edge-to-edge) dan tetap rapi saat layar diputar.
 *  - GameOptions: membaca pilihan Warna / Waktu / Level dari layout include_game_options.xml.
 */
fun View.applySystemBarInsets() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
        v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
        insets
    }
    ViewCompat.requestApplyInsets(this)
}

object GameOptions {
    /** Siapkan spinner: tampilkan/sembunyikan baris warna & level, set default. */
    fun init(root: View, showColor: Boolean, showLevel: Boolean) {
        root.findViewById<View>(R.id.rowColor).visibility = if (showColor) View.VISIBLE else View.GONE
        root.findViewById<View>(R.id.rowLevel).visibility = if (showLevel) View.VISIBLE else View.GONE
        root.findViewById<Spinner>(R.id.spLevel).setSelection(1)
        root.findViewById<Spinner>(R.id.spTime).setSelection(0)
    }

    /** true = bermain Putih. Pilihan "Acak" diundi di sini. */
    fun isWhite(root: View): Boolean = when (root.findViewById<Spinner>(R.id.spColor).selectedItemPosition) {
        0 -> true
        1 -> false
        else -> Random.nextBoolean()
    }

    fun minutes(root: View): Int {
        val values = root.resources.getIntArray(R.array.time_values)
        return values[root.findViewById<Spinner>(R.id.spTime).selectedItemPosition]
    }

    fun level(root: View): Int = root.findViewById<Spinner>(R.id.spLevel).selectedItemPosition + 1
}

/** Format durasi: 05:12 atau 1:05:12. */
fun formatDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}
