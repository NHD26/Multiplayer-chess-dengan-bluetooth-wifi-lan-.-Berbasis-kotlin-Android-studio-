package id.catur.game.engine

/*
 * FILE: Piece.kt  (folder engine/)
 * Fungsi: konstanta bidak + helper nilai/ikon bidak.
 * Representasi: angka positif = bidak PUTIH, negatif = bidak HITAM.
 *   Contoh: +1 = pion putih, -5 = ratu hitam. 0 = petak kosong.
 */

const val EMPTY = 0
const val PAWN = 1
const val KNIGHT = 2
const val BISHOP = 3
const val ROOK = 4
const val QUEEN = 5
const val KING = 6

/** Simbol Unicode bidak (varian "solid", diberi VS15 agar tidak dirender sebagai emoji). */
fun pieceGlyph(type: Int): String = when (type) {
    KING -> "\u265A\uFE0E"
    QUEEN -> "\u265B\uFE0E"
    ROOK -> "\u265C\uFE0E"
    BISHOP -> "\u265D\uFE0E"
    KNIGHT -> "\u265E\uFE0E"
    PAWN -> "\u265F\uFE0E"
    else -> ""
}

/** Poin material ala chess.com: pion 1, kuda 3, gajah 3, benteng 5, ratu 9. */
fun piecePoints(type: Int): Int = when (type) {
    PAWN -> 1
    KNIGHT, BISHOP -> 3
    ROOK -> 5
    QUEEN -> 9
    else -> 0
}
