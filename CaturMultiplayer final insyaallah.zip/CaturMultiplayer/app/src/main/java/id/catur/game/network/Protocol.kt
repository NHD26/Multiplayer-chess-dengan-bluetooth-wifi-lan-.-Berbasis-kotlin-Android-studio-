package id.catur.game.network

import java.util.UUID

/*
 * FILE: Protocol.kt  (folder network/)
 * Fungsi: aturan "bahasa" antar dua HP. Setiap pesan = 1 baris teks "JENIS|arg1|arg2|...".
 * Dipakai sama persis oleh WiFi (TCP) maupun Bluetooth (RFCOMM).
 *   HELLO|nama|rating                     perkenalan saat tersambung
 *   START|warnaLawan(W/B)|menit|token     host memulai partai (token = ID partai untuk reconnect)
 *   MOVE|dari,ke,promosi                  langkah catur
 *   RESIGN / DRAW_OFFER / DRAW_ACCEPT / DRAW_DECLINE
 *   REMATCH_REQ / REMATCH_OK              main lagi (warna ditukar)
 *   CHAT|teks                             chat singkat
 *   PING                                  detak jantung untuk mendeteksi koneksi mati
 *   SYNC|token|daftarLangkah|msPutih|msHitam   sinkronisasi saat tersambung kembali
 */
object Protocol {
    const val PORT = 8765
    val BT_UUID: UUID = UUID.fromString("8f3a1c52-7d44-4b0e-9a56-2c1e6b7d9f01")

    const val SEP = "|"
    const val HELLO = "HELLO"
    const val START = "START"
    const val MOVE = "MOVE"
    const val RESIGN = "RESIGN"
    const val DRAW_OFFER = "DRAW_OFFER"
    const val DRAW_ACCEPT = "DRAW_ACCEPT"
    const val DRAW_DECLINE = "DRAW_DECLINE"
    const val REMATCH_REQ = "REMATCH_REQ"
    const val REMATCH_OK = "REMATCH_OK"
    const val CHAT = "CHAT"
    const val PING = "PING"
    const val SYNC = "SYNC"

    fun build(type: String, vararg parts: String): String {
        val sb = StringBuilder(type)
        for (p in parts) sb.append(SEP).append(clean(p))
        return sb.toString()
    }

    private fun clean(s: String): String = s.replace("|", "/").replace("\n", " ").replace("\r", " ")

    fun parse(line: String): Pair<String, List<String>> {
        val p = line.split(SEP)
        return Pair(p[0], p.drop(1))
    }
}
