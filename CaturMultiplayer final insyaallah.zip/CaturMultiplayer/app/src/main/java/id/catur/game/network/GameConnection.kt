package id.catur.game.network

import android.os.Handler
import android.os.Looper

/** Sesuatu yang bisa dibatalkan (server yang sedang menunggu lawan). */
interface Cancelable {
    fun cancel()
}

/*
 * FILE: GameConnection.kt  (folder network/)
 * Fungsi: kelas dasar sebuah koneksi ke lawan (tidak peduli WiFi atau Bluetooth).
 * Semua callback dikirim ke MAIN THREAD. Pesan yang datang saat belum ada listener
 * disimpan dulu lalu dikirim begitu listener dipasang (penting saat pindah layar).
 */
abstract class GameConnection {
    interface Listener {
        fun onMessage(line: String)
        fun onClosed()
    }

    private val main = Handler(Looper.getMainLooper())
    private val pending = ArrayList<String>()
    private var closedPending = false
    private var listener: Listener? = null

    @Volatile
    var closed = false
        protected set

    /** Panggil dari main thread. */
    fun setListener(l: Listener?) {
        listener = l
        if (l == null) return
        while (listener === l && pending.isNotEmpty()) l.onMessage(pending.removeAt(0))
        if (closedPending && listener === l) {
            closedPending = false
            l.onClosed()
        }
    }

    protected fun deliver(line: String) {
        main.post {
            val l = listener
            if (l != null) l.onMessage(line) else pending.add(line)
        }
    }

    protected fun deliverClosed() {
        main.post {
            val l = listener
            if (l != null) l.onClosed() else closedPending = true
        }
    }

    abstract fun send(line: String)
    abstract fun close()
}
