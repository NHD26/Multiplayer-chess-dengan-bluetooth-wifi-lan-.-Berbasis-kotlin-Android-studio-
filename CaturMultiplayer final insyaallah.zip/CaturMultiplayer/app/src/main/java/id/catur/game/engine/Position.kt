package id.catur.game.engine

import kotlin.math.abs

/*
 * FILE: Position.kt  (folder engine/)
 * Fungsi: INTI ATURAN CATUR. Satu posisi papan + semua aturan resmi:
 *  - gerak semua bidak, tangkap, skak (raja tidak pernah bisa dimakan: langkah yang
 *    membiarkan raja sendiri diserang DIBUANG dari daftar langkah legal)
 *  - rokade (hak hilang bila raja/benteng pernah jalan atau benteng dimakan; tidak boleh
 *    saat skak, melewati petak diserang, atau mendarat di petak diserang)
 *  - en passant, promosi pion (Ratu/Benteng/Gajah/Kuda), pin, skakmat, stalemate
 * Posisi bersifat immutable: apply() menghasilkan Position baru.
 * Indeks petak: baris*8+kolom, baris 0 = rank 8 (atas), kolom 0 = file a.
 */
class Position(
    val board: IntArray,
    val whiteToMove: Boolean = true,
    val castling: Int = 15,          // bit: 1=K putih, 2=Q putih, 4=k hitam, 8=q hitam
    val enPassant: Int = -1,         // petak tujuan en passant, -1 jika tidak ada
    val halfmoveClock: Int = 0,      // untuk aturan 50 langkah
    val fullmoveNumber: Int = 1
) {
    companion object {
        const val WK = 1
        const val WQ = 2
        const val BK = 4
        const val BQ = 8

        private val KN_R = intArrayOf(-2, -2, -1, -1, 1, 1, 2, 2)
        private val KN_C = intArrayOf(-1, 1, -2, 2, -2, 2, -1, 1)
        private val KG_R = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)
        private val KG_C = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)
        private val DIAG_R = intArrayOf(-1, -1, 1, 1)
        private val DIAG_C = intArrayOf(-1, 1, -1, 1)
        private val STR_R = intArrayOf(-1, 1, 0, 0)
        private val STR_C = intArrayOf(0, 0, -1, 1)

        fun initial(): Position {
            val b = IntArray(64)
            val back = intArrayOf(ROOK, KNIGHT, BISHOP, QUEEN, KING, BISHOP, KNIGHT, ROOK)
            for (c in 0 until 8) {
                b[c] = -back[c]
                b[8 + c] = -PAWN
                b[48 + c] = PAWN
                b[56 + c] = back[c]
            }
            return Position(b)
        }

        /** Membaca FEN (dipakai unit test & bisa untuk fitur lanjutan). */
        fun fromFen(fen: String): Position {
            val parts = fen.trim().split(" ")
            val b = IntArray(64)
            var sq = 0
            for (ch in parts[0]) {
                when {
                    ch == '/' -> {}
                    ch.isDigit() -> sq += ch - '0'
                    else -> {
                        val t = when (ch.lowercaseChar()) {
                            'p' -> PAWN
                            'n' -> KNIGHT
                            'b' -> BISHOP
                            'r' -> ROOK
                            'q' -> QUEEN
                            else -> KING
                        }
                        b[sq] = if (ch.isUpperCase()) t else -t
                        sq++
                    }
                }
            }
            val white = parts.getOrElse(1) { "w" } == "w"
            val cs = parts.getOrElse(2) { "-" }
            var c = 0
            if ('K' in cs) c = c or WK
            if ('Q' in cs) c = c or WQ
            if ('k' in cs) c = c or BK
            if ('q' in cs) c = c or BQ
            val epS = parts.getOrElse(3) { "-" }
            val ep = if (epS == "-") -1 else Move.squareIndex(epS)
            val hm = parts.getOrNull(4)?.toIntOrNull() ?: 0
            val fm = parts.getOrNull(5)?.toIntOrNull() ?: 1
            return Position(b, white, c, ep, hm, fm)
        }
    }

    // ------------------------------------------------------------------ serangan / skak

    /** Apakah petak [sq] sedang diserang oleh pihak putih ([byWhite]=true) atau hitam. */
    fun isAttacked(sq: Int, byWhite: Boolean): Boolean {
        val r = sq / 8
        val c = sq % 8
        val sg = if (byWhite) 1 else -1
        val pr = if (byWhite) r + 1 else r - 1          // pion putih menyerang ke atas
        if (pr in 0..7) {
            if (c > 0 && board[pr * 8 + c - 1] == sg * PAWN) return true
            if (c < 7 && board[pr * 8 + c + 1] == sg * PAWN) return true
        }
        for (i in 0 until 8) {
            var rr = r + KN_R[i]
            var cc = c + KN_C[i]
            if (rr in 0..7 && cc in 0..7 && board[rr * 8 + cc] == sg * KNIGHT) return true
            rr = r + KG_R[i]
            cc = c + KG_C[i]
            if (rr in 0..7 && cc in 0..7 && board[rr * 8 + cc] == sg * KING) return true
        }
        if (slideHit(r, c, DIAG_R, DIAG_C, sg, BISHOP)) return true
        return slideHit(r, c, STR_R, STR_C, sg, ROOK)
    }

    private fun slideHit(r: Int, c: Int, dr: IntArray, dc: IntArray, sg: Int, t: Int): Boolean {
        for (i in 0 until 4) {
            var rr = r + dr[i]
            var cc = c + dc[i]
            while (rr in 0..7 && cc in 0..7) {
                val p = board[rr * 8 + cc]
                if (p != 0) {
                    if (p == sg * t || p == sg * QUEEN) return true
                    break
                }
                rr += dr[i]
                cc += dc[i]
            }
        }
        return false
    }

    fun kingSquare(white: Boolean): Int = board.indexOf(if (white) KING else -KING)

    /** Apakah raja pihak [white] sedang skak. */
    fun inCheck(white: Boolean = whiteToMove): Boolean {
        val k = kingSquare(white)
        return k >= 0 && isAttacked(k, !white)
    }

    // ------------------------------------------------------------------ generator langkah

    /** Langkah "pseudo-legal": sesuai gerak bidak, tapi belum dicek apakah raja jadi terancam. */
    fun pseudoMoves(): ArrayList<Move> {
        val list = ArrayList<Move>(48)
        for (sq in 0 until 64) {
            val p = board[sq]
            if (p == 0 || (p > 0) != whiteToMove) continue
            val r = sq / 8
            val c = sq % 8
            when (abs(p)) {
                PAWN -> genPawn(list, sq, r, c)
                KNIGHT -> genStep(list, sq, r, c, KN_R, KN_C)
                KING -> genStep(list, sq, r, c, KG_R, KG_C)
                BISHOP -> genSlide(list, sq, r, c, DIAG_R, DIAG_C)
                ROOK -> genSlide(list, sq, r, c, STR_R, STR_C)
                QUEEN -> {
                    genSlide(list, sq, r, c, DIAG_R, DIAG_C)
                    genSlide(list, sq, r, c, STR_R, STR_C)
                }
            }
        }
        genCastling(list)
        return list
    }

    private fun addPawnMove(list: ArrayList<Move>, from: Int, to: Int, promotes: Boolean) {
        if (promotes) {
            list.add(Move(from, to, QUEEN))
            list.add(Move(from, to, ROOK))
            list.add(Move(from, to, BISHOP))
            list.add(Move(from, to, KNIGHT))
        } else {
            list.add(Move(from, to))
        }
    }

    private fun genPawn(list: ArrayList<Move>, sq: Int, r: Int, c: Int) {
        val dir = if (whiteToMove) -1 else 1
        val startRow = if (whiteToMove) 6 else 1
        val promoRow = if (whiteToMove) 0 else 7
        val r1 = r + dir
        if (r1 !in 0..7) return
        if (board[r1 * 8 + c] == 0) {
            addPawnMove(list, sq, r1 * 8 + c, r1 == promoRow)
            if (r == startRow && board[(r + 2 * dir) * 8 + c] == 0) {
                list.add(Move(sq, (r + 2 * dir) * 8 + c))
            }
        }
        for (dc in intArrayOf(-1, 1)) {
            val cc = c + dc
            if (cc !in 0..7) continue
            val to = r1 * 8 + cc
            val tp = board[to]
            if ((tp != 0 && (tp > 0) != whiteToMove) || (tp == 0 && to == enPassant)) {
                addPawnMove(list, sq, to, r1 == promoRow)
            }
        }
    }

    private fun genStep(list: ArrayList<Move>, sq: Int, r: Int, c: Int, dr: IntArray, dc: IntArray) {
        for (i in dr.indices) {
            val rr = r + dr[i]
            val cc = c + dc[i]
            if (rr !in 0..7 || cc !in 0..7) continue
            val tp = board[rr * 8 + cc]
            if (tp == 0 || (tp > 0) != whiteToMove) list.add(Move(sq, rr * 8 + cc))
        }
    }

    private fun genSlide(list: ArrayList<Move>, sq: Int, r: Int, c: Int, dr: IntArray, dc: IntArray) {
        for (i in dr.indices) {
            var rr = r + dr[i]
            var cc = c + dc[i]
            while (rr in 0..7 && cc in 0..7) {
                val tp = board[rr * 8 + cc]
                if (tp == 0) {
                    list.add(Move(sq, rr * 8 + cc))
                } else {
                    if ((tp > 0) != whiteToMove) list.add(Move(sq, rr * 8 + cc))
                    break
                }
                rr += dr[i]
                cc += dc[i]
            }
        }
    }

    private fun genCastling(list: ArrayList<Move>) {
        val base = if (whiteToMove) 56 else 0
        val king = base + 4
        val sg = if (whiteToMove) 1 else -1
        if (board[king] != sg * KING) return
        val kBit = if (whiteToMove) WK else BK
        val qBit = if (whiteToMove) WQ else BQ
        if ((castling and (kBit or qBit)) == 0) return
        val enemyWhite = !whiteToMove
        if (isAttacked(king, enemyWhite)) return                       // tidak boleh rokade saat skak
        if ((castling and kBit) != 0 &&
            board[base + 7] == sg * ROOK && board[base + 5] == 0 && board[base + 6] == 0 &&
            !isAttacked(base + 5, enemyWhite) && !isAttacked(base + 6, enemyWhite)
        ) list.add(Move(king, king + 2))
        if ((castling and qBit) != 0 &&
            board[base] == sg * ROOK && board[base + 1] == 0 && board[base + 2] == 0 && board[base + 3] == 0 &&
            !isAttacked(base + 3, enemyWhite) && !isAttacked(base + 2, enemyWhite)
        ) list.add(Move(king, king - 2))
    }

    /** Hanya langkah LEGAL: raja sendiri tidak boleh berada dalam serangan setelah melangkah. */
    fun legalMoves(): List<Move> {
        val out = ArrayList<Move>(40)
        for (m in pseudoMoves()) {
            val n = apply(m)
            if (!n.inCheck(whiteToMove)) out.add(m)
        }
        return out
    }

    // ------------------------------------------------------------------ menjalankan langkah

    /** Menghasilkan posisi baru setelah [m] (diasumsikan legal). */
    fun apply(m: Move): Position {
        val nb = board.copyOf()
        val p = nb[m.from]
        val t = abs(p)
        val captured = nb[m.to]
        var newEp = -1
        var newCastling = castling
        nb[m.to] = p
        nb[m.from] = 0
        if (t == PAWN) {
            // en passant: pion pindah diagonal ke petak kosong -> pion lawan di sampingnya dimakan
            if (captured == 0 && m.from % 8 != m.to % 8) nb[(m.from / 8) * 8 + m.to % 8] = 0
            if (abs(m.to - m.from) == 16) newEp = (m.from + m.to) / 2
            if (m.promo != 0) nb[m.to] = (if (p > 0) 1 else -1) * m.promo
        }
        if (t == KING) {
            if (m.to - m.from == 2) {          // rokade sisi raja: benteng h -> f
                nb[m.from + 1] = nb[m.from + 3]
                nb[m.from + 3] = 0
            } else if (m.to - m.from == -2) {  // rokade sisi ratu: benteng a -> d
                nb[m.from - 1] = nb[m.from - 4]
                nb[m.from - 4] = 0
            }
            newCastling = newCastling and (if (p > 0) 3 else 12).inv()
        }
        newCastling = newCastling and rookMask(m.from) and rookMask(m.to)
        val hm = if (t == PAWN || captured != 0) 0 else halfmoveClock + 1
        return Position(nb, !whiteToMove, newCastling, newEp, hm, fullmoveNumber + if (whiteToMove) 0 else 1)
    }

    private fun rookMask(sq: Int): Int = when (sq) {
        63 -> WK.inv()
        56 -> WQ.inv()
        7 -> BK.inv()
        0 -> BQ.inv()
        else -> -1
    }

    /** Kunci unik posisi (untuk deteksi remis pengulangan 3x). */
    fun key(): String = board.joinToString(",") + (if (whiteToMove) "w" else "b") + castling + "_" + enPassant
}
