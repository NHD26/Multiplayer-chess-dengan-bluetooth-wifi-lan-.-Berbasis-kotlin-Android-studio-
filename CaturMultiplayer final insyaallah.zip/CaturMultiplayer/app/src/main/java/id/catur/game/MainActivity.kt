package id.catur.game

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import id.catur.game.util.GameOptions
import id.catur.game.util.StatsStore
import id.catur.game.util.applySystemBarInsets

/*
 * FILE: MainActivity.kt  (folder id/catur/game/)
 * Fungsi: MENU UTAMA. Pilihan: Lawan Komputer, 2 Pemain (1 HP), Main via WiFi/Hotspot,
 * Main via Bluetooth, Statistik, Pengaturan. Menampilkan rating pemain.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.root).applySystemBarInsets()

        findViewById<View>(R.id.btnAi).setOnClickListener { showOptions(GameActivity.MODE_AI) }
        findViewById<View>(R.id.btnLocal).setOnClickListener { showOptions(GameActivity.MODE_LOCAL) }
        findViewById<View>(R.id.btnWifi).setOnClickListener {
            startActivity(Intent(this, WifiLobbyActivity::class.java))
        }
        findViewById<View>(R.id.btnBt).setOnClickListener {
            startActivity(Intent(this, BluetoothLobbyActivity::class.java))
        }
        findViewById<View>(R.id.btnStats).setOnClickListener {
            startActivity(Intent(this, StatsActivity::class.java))
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        findViewById<android.widget.TextView>(R.id.tvMenuRating).text =
            getString(R.string.menu_rating, StatsStore.rating(this))
    }

    private fun showOptions(mode: String) {
        val v = layoutInflater.inflate(R.layout.include_game_options, null)
        val pad = (20 * resources.displayMetrics.density).toInt()
        v.setPadding(pad, pad / 2, pad, 0)
        val isAi = mode == GameActivity.MODE_AI
        GameOptions.init(v, showColor = isAi, showLevel = isAi)
        AlertDialog.Builder(this)
            .setTitle(if (isAi) R.string.menu_vs_ai else R.string.menu_local)
            .setView(v)
            .setPositiveButton(R.string.start) { _, _ ->
                val white = if (isAi) GameOptions.isWhite(v) else true
                startActivity(
                    GameActivity.intent(this, mode, white, GameOptions.minutes(v), GameOptions.level(v))
                )
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
