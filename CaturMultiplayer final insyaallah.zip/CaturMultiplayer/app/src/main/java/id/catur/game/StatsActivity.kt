package id.catur.game

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import id.catur.game.util.StatsStore
import id.catur.game.util.applySystemBarInsets
import id.catur.game.util.formatDuration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * FILE: StatsActivity.kt  (folder id/catur/game/)
 * Fungsi: layar STATISTIK ala chess.com: rating (poin), rekor menang/seri/kalah,
 * dan riwayat 50 partai (tanggal, lawan, hasil, poin, durasi, jumlah langkah).
 */
class StatsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)
        findViewById<View>(R.id.root).applySystemBarInsets()
        findViewById<View>(R.id.btnReset).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.stats_reset_confirm)
                .setPositiveButton(R.string.yes) { _, _ ->
                    StatsStore.reset(this)
                    refresh()
                }
                .setNegativeButton(R.string.no, null)
                .show()
        }
        refresh()
    }

    private fun refresh() {
        findViewById<TextView>(R.id.tvRating).text = getString(R.string.stats_rating, StatsStore.rating(this))
        findViewById<TextView>(R.id.tvRecord).text = getString(
            R.string.stats_record, StatsStore.wins(this), StatsStore.draws(this), StatsStore.losses(this)
        )
        val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())
        val lines = StatsStore.history(this).map { r ->
            val res = getString(
                when (r.result) {
                    1 -> R.string.res_win
                    0 -> R.string.res_draw
                    else -> R.string.res_loss
                }
            )
            val delta = if (r.delta >= 0) "+${r.delta}" else "${r.delta}"
            getString(
                R.string.stats_row, fmt.format(Date(r.time)), r.opponent, res, delta,
                formatDuration(r.durationMs), r.moves
            )
        }
        val shown = if (lines.isEmpty()) listOf(getString(R.string.stats_empty)) else lines
        findViewById<ListView>(R.id.lvHistory).adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, shown)
    }
}
