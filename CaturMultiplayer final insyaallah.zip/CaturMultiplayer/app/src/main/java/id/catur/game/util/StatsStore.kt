package id.catur.game.util

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/** Satu baris riwayat partai. result: 1 = menang, 0 = seri, -1 = kalah. */
data class GameRecord(
    val time: Long,
    val mode: String,
    val opponent: String,
    val result: Int,
    val delta: Int,
    val durationMs: Long,
    val moves: Int
)

/*
 * FILE: StatsStore.kt  (folder util/)
 * Fungsi: poin rating (sistem Elo seperti chess.com, awal 800), rekor menang/seri/kalah,
 * dan riwayat 50 partai terakhir (tanggal, lawan, hasil, poin, durasi, jumlah langkah).
 */
object StatsStore {
    private const val K = 32.0
    private const val MIN_RATING = 100

    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("catur_stats", Context.MODE_PRIVATE)

    fun rating(c: Context): Int = sp(c).getInt("rating", 800)
    fun wins(c: Context): Int = sp(c).getInt("wins", 0)
    fun draws(c: Context): Int = sp(c).getInt("draws", 0)
    fun losses(c: Context): Int = sp(c).getInt("losses", 0)

    /** Perubahan rating Elo. [score]: 1.0 menang, 0.5 seri, 0.0 kalah. */
    fun eloDelta(myRating: Int, oppRating: Int, score: Double): Int {
        val expected = 1.0 / (1.0 + 10.0.pow((oppRating - myRating) / 400.0))
        return (K * (score - expected)).roundToInt()
    }

    /** Menyimpan hasil partai dan mengembalikan rating baru. */
    fun record(c: Context, rec: GameRecord): Int {
        val p = sp(c)
        val newRating = max(MIN_RATING, rating(c) + rec.delta)
        val e = p.edit()
        e.putInt("rating", newRating)
        when (rec.result) {
            1 -> e.putInt("wins", wins(c) + 1)
            0 -> e.putInt("draws", draws(c) + 1)
            else -> e.putInt("losses", losses(c) + 1)
        }
        val list = ArrayList<GameRecord>()
        list.add(rec)
        list.addAll(history(c))
        val arr = JSONArray()
        for (r in list.take(50)) {
            val o = JSONObject()
            o.put("t", r.time)
            o.put("mode", r.mode)
            o.put("opp", r.opponent)
            o.put("res", r.result)
            o.put("d", r.delta)
            o.put("ms", r.durationMs)
            o.put("mv", r.moves)
            arr.put(o)
        }
        e.putString("history", arr.toString())
        e.apply()
        return newRating
    }

    fun history(c: Context): List<GameRecord> {
        val out = ArrayList<GameRecord>()
        try {
            val arr = JSONArray(sp(c).getString("history", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    GameRecord(
                        o.getLong("t"), o.getString("mode"), o.getString("opp"),
                        o.getInt("res"), o.getInt("d"), o.getLong("ms"), o.getInt("mv")
                    )
                )
            }
        } catch (e: JSONException) {
            // data rusak: abaikan
        }
        return out
    }

    fun reset(c: Context) {
        sp(c).edit().clear().apply()
    }
}
