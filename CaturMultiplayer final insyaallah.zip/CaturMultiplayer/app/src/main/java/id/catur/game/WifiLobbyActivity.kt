package id.catur.game

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import id.catur.game.network.ClientReconnect
import id.catur.game.network.ConnectionHolder
import id.catur.game.network.GameConnection
import id.catur.game.network.Handshake
import id.catur.game.network.HostReconnect
import id.catur.game.network.Protocol
import id.catur.game.network.ReconnectStrategy
import id.catur.game.network.Session
import id.catur.game.network.WifiClient
import id.catur.game.network.WifiHost
import id.catur.game.util.GameOptions
import id.catur.game.util.NetUtils
import id.catur.game.util.Prefs
import id.catur.game.util.StatsStore
import id.catur.game.util.applySystemBarInsets

/*
 * FILE: WifiLobbyActivity.kt  (folder id/catur/game/)
 * Fungsi: LOBI WiFi LAN / HOTSPOT.
 *  - HOST  : pilih warna & waktu, tekan "Buat Room", beri tahu IP yang tampil ke teman.
 *  - GABUNG: isi IP host (otomatis terisi IP gateway = IP pemilik hotspot) lalu "Gabung".
 * Setelah tersambung & handshake selesai, pindah ke GameActivity.
 */
class WifiLobbyActivity : AppCompatActivity() {
    private var host: WifiHost? = null
    private var pendingConn: GameConnection? = null
    private var launched = false
    private var busy = false

    private lateinit var options: View
    private lateinit var btnHost: MaterialButton
    private lateinit var tvStatus: TextView
    private lateinit var tvIp: TextView
    private lateinit var etIp: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wifi_lobby)
        findViewById<View>(R.id.root).applySystemBarInsets()
        options = findViewById(R.id.options)
        btnHost = findViewById(R.id.btnHost)
        tvStatus = findViewById(R.id.tvStatus)
        tvIp = findViewById(R.id.tvIp)
        etIp = findViewById(R.id.etIp)
        GameOptions.init(options, showColor = true, showLevel = false)
        etIp.setText(NetUtils.gatewayIp(this) ?: "")

        btnHost.setOnClickListener { if (host != null) stopHosting() else startHosting() }
        findViewById<View>(R.id.btnJoin).setOnClickListener { join() }
    }

    private fun startHosting() {
        if (busy) return
        val hostWhite = GameOptions.isWhite(options)
        val minutes = GameOptions.minutes(options)
        val ips = NetUtils.localIpv4()
        tvIp.text = if (ips.isEmpty()) getString(R.string.wifi_no_ip)
        else getString(R.string.wifi_your_ip, ips.joinToString(", "), Protocol.PORT)
        tvStatus.setText(R.string.wifi_waiting)
        btnHost.setText(R.string.cancel)
        busy = true
        host = WifiHost { conn, err ->
            host = null
            busy = false
            btnHost.setText(R.string.wifi_host)
            if (conn == null) {
                tvStatus.text = getString(R.string.conn_failed, err ?: "")
            } else {
                onConnected(conn, true, hostWhite, minutes, "")
            }
        }.also { it.start() }
    }

    private fun stopHosting() {
        host?.cancel()
        host = null
        busy = false
        btnHost.setText(R.string.wifi_host)
        tvStatus.text = ""
    }

    private fun join() {
        if (busy) return
        val ip = etIp.text.toString().trim()
        if (ip.isEmpty()) {
            Toast.makeText(this, R.string.wifi_ip_empty, Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        tvStatus.text = getString(R.string.wifi_connecting, ip)
        WifiClient.connect(ip) { conn, err ->
            busy = false
            if (conn == null) {
                tvStatus.text = getString(R.string.conn_failed, err ?: "")
            } else {
                onConnected(conn, false, true, 0, ip)
            }
        }
    }

    private fun onConnected(conn: GameConnection, isHost: Boolean, hostWhite: Boolean, minutes: Int, ip: String) {
        pendingConn = conn
        busy = true
        tvStatus.setText(R.string.handshaking)
        val name = Prefs.playerName(this)
        val rating = StatsStore.rating(this)
        if (isHost) {
            Handshake.host(conn, name, rating, hostWhite, minutes,
                onReady = { s ->
                    launch(conn, true, s, HostReconnect { cb -> WifiHost(cb).also { it.start() } })
                },
                onFail = { fail() })
        } else {
            Handshake.client(conn, name, rating,
                onReady = { s ->
                    launch(conn, false, s, ClientReconnect { cb -> WifiClient.connect(ip, cb) })
                },
                onFail = { fail() })
        }
    }

    private fun launch(conn: GameConnection, isHost: Boolean, s: Session, strategy: ReconnectStrategy) {
        launched = true
        ConnectionHolder.begin(conn, isHost, s.token, strategy)
        startActivity(
            GameActivity.intent(this, GameActivity.MODE_ONLINE, s.myWhite, s.minutes, peer = s.peerName, peerRating = s.peerRating)
        )
        finish()
    }

    private fun fail() {
        pendingConn?.close()
        pendingConn = null
        busy = false
        tvStatus.setText(R.string.conn_dropped)
    }

    override fun onDestroy() {
        super.onDestroy()
        host?.cancel()
        if (!launched) pendingConn?.close()
    }
}
