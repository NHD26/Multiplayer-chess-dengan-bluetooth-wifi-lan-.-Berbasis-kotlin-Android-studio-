package id.catur.game

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import id.catur.game.network.BluetoothClient
import id.catur.game.network.BluetoothHost
import id.catur.game.network.ClientReconnect
import id.catur.game.network.ConnectionHolder
import id.catur.game.network.GameConnection
import id.catur.game.network.Handshake
import id.catur.game.network.HostReconnect
import id.catur.game.network.ReconnectStrategy
import id.catur.game.network.Session
import id.catur.game.util.GameOptions
import id.catur.game.util.Prefs
import id.catur.game.util.StatsStore
import id.catur.game.util.applySystemBarInsets

/*
 * FILE: BluetoothLobbyActivity.kt  (folder id/catur/game/)
 * Fungsi: LOBI BLUETOOTH.
 *  - HOST  : pilih warna & waktu, "Jadi Host" (perangkat dibuat terlihat 5 menit & menunggu lawan).
 *  - GABUNG: "Cari Perangkat" (daftar perangkat terpasang + hasil scan), ketuk nama host.
 * Mengurus izin runtime Bluetooth (Android 12+: CONNECT/SCAN/ADVERTISE, Android 11-: Lokasi)
 * dan permintaan menyalakan Bluetooth.
 */
@SuppressLint("MissingPermission")
class BluetoothLobbyActivity : AppCompatActivity() {
    private var adapter: BluetoothAdapter? = null
    private var host: BluetoothHost? = null
    private var pendingConn: GameConnection? = null
    private var launched = false
    private var busy = false
    private var receiverRegistered = false
    private var pendingAction: (() -> Unit)? = null
    private var hostWhite = true
    private var hostMinutes = 0

    private val devices = ArrayList<BluetoothDevice>()
    private val labels = ArrayList<String>()
    private lateinit var listAdapter: ArrayAdapter<String>
    private lateinit var options: View
    private lateinit var btnHost: MaterialButton
    private lateinit var btnScan: MaterialButton
    private lateinit var tvStatus: TextView

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            val a = pendingAction
            pendingAction = null
            if (res.values.all { it }) a?.invoke() else toast(R.string.bt_perm_denied)
        }

    private val enableLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val a = pendingAction
            pendingAction = null
            if (r.resultCode == RESULT_OK) a?.invoke() else toast(R.string.bt_must_enable)
        }

    private val discoverableLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            beginListening()
        }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d = deviceFrom(intent) ?: return
                    addDevice(d)
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    btnScan.setText(R.string.bt_scan)
                    if (!busy) tvStatus.setText(R.string.bt_scan_done)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bt_lobby)
        findViewById<View>(R.id.root).applySystemBarInsets()
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

        options = findViewById(R.id.options)
        btnHost = findViewById(R.id.btnBtHost)
        btnScan = findViewById(R.id.btnScan)
        tvStatus = findViewById(R.id.tvStatus)
        GameOptions.init(options, showColor = true, showLevel = false)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, labels)
        val lv = findViewById<ListView>(R.id.lvDevices)
        lv.adapter = listAdapter
        // ListView di dalam ScrollView: biarkan list menggulir sendiri
        lv.setOnTouchListener { v, _ ->
            v.parent.requestDisallowInterceptTouchEvent(true)
            false
        }
        lv.setOnItemClickListener { _, _, pos, _ -> connectTo(pos) }

        btnHost.setOnClickListener {
            if (host != null) stopHosting() else withBluetooth { startDiscoverable() }
        }
        btnScan.setOnClickListener { withBluetooth { scan() } }

        if (adapter == null) tvStatus.setText(R.string.bt_unsupported)
    }

    // ------------------------------------------------------------------ izin & Bluetooth aktif

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private fun withBluetooth(action: () -> Unit) {
        val a = adapter
        if (a == null) {
            toast(R.string.bt_unsupported)
            return
        }
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            pendingAction = { withBluetooth(action) }
            permLauncher.launch(missing.toTypedArray())
            return
        }
        if (!a.isEnabled) {
            pendingAction = { withBluetooth(action) }
            enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }
        action()
    }

    // ------------------------------------------------------------------ HOST

    private fun startDiscoverable() {
        if (busy) return
        hostWhite = GameOptions.isWhite(options)
        hostMinutes = GameOptions.minutes(options)
        val i = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
            .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
        discoverableLauncher.launch(i)
    }

    private fun beginListening() {
        val a = adapter ?: return
        if (host != null) return
        busy = true
        btnHost.setText(R.string.cancel)
        tvStatus.setText(R.string.bt_waiting)
        host = BluetoothHost(a) { conn, err ->
            host = null
            busy = false
            btnHost.setText(R.string.bt_host)
            if (conn == null) {
                tvStatus.text = getString(R.string.conn_failed, err ?: "")
            } else {
                onConnected(conn, true, null)
            }
        }.also { it.start() }
    }

    private fun stopHosting() {
        host?.cancel()
        host = null
        busy = false
        btnHost.setText(R.string.bt_host)
        tvStatus.text = ""
    }

    // ------------------------------------------------------------------ KLIEN

    private fun scan() {
        val a = adapter ?: return
        devices.clear()
        labels.clear()
        for (d in a.bondedDevices) addDevice(d)
        if (!receiverRegistered) {
            val f = IntentFilter(BluetoothDevice.ACTION_FOUND)
            f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
            receiverRegistered = true
        }
        if (a.isDiscovering) a.cancelDiscovery()
        a.startDiscovery()
        btnScan.setText(R.string.bt_scanning)
        tvStatus.setText(R.string.bt_pick)
    }

    private fun addDevice(d: BluetoothDevice) {
        if (devices.any { it.address == d.address }) return
        devices.add(d)
        val paired = if (d.bondState == BluetoothDevice.BOND_BONDED) " · " + getString(R.string.bt_paired) else ""
        labels.add((d.name ?: getString(R.string.bt_unknown)) + "\n" + d.address + paired)
        listAdapter.notifyDataSetChanged()
    }

    @Suppress("DEPRECATION")
    private fun deviceFrom(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }

    private fun connectTo(pos: Int) {
        if (busy) return
        val a = adapter ?: return
        val dev = devices.getOrNull(pos) ?: return
        busy = true
        tvStatus.text = getString(R.string.bt_connecting, dev.name ?: dev.address)
        BluetoothClient(a).connect(dev) { conn, err ->
            busy = false
            if (conn == null) {
                tvStatus.text = getString(R.string.conn_failed, err ?: "")
            } else {
                onConnected(conn, false, dev)
            }
        }
    }

    // ------------------------------------------------------------------ handshake & mulai

    private fun onConnected(conn: GameConnection, isHost: Boolean, dev: BluetoothDevice?) {
        val a = adapter
        if (a == null) {
            conn.close()
            return
        }
        pendingConn = conn
        busy = true
        tvStatus.setText(R.string.handshaking)
        val name = Prefs.playerName(this)
        val rating = StatsStore.rating(this)
        if (isHost) {
            Handshake.host(conn, name, rating, hostWhite, hostMinutes,
                onReady = { s ->
                    launch(conn, true, s, HostReconnect { cb -> BluetoothHost(a, cb).also { it.start() } })
                },
                onFail = { fail() })
        } else if (dev != null) {
            Handshake.client(conn, name, rating,
                onReady = { s ->
                    launch(conn, false, s, ClientReconnect { cb -> BluetoothClient(a).connect(dev, cb) })
                },
                onFail = { fail() })
        }
    }

    private fun launch(conn: GameConnection, isHost: Boolean, s: Session, strategy: ReconnectStrategy) {
        launched = true
        ConnectionHolder.begin(conn, isHost, s.token, strategy)
        startActivity(
            GameActivity.intent(this, GameActivity.MODE_ONLINE, s.myWhite, s.minutes, peer = s.peerName, peerRating = s.peerRating)
        )
        finish()
    }

    private fun fail() {
        pendingConn?.close()
        pendingConn = null
        busy = false
        tvStatus.setText(R.string.conn_dropped)
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        if (receiverRegistered) unregisterReceiver(receiver)
        try {
            adapter?.cancelDiscovery()
        } catch (e: SecurityException) {
            // izin dicabut: abaikan
        }
        host?.cancel()
        if (!launched) pendingConn?.close()
    }
}
