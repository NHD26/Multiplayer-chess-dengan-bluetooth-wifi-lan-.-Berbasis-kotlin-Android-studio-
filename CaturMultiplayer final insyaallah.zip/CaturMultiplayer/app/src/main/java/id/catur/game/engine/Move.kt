package id.catur.game.engine

/*
 * FILE: Move.kt  (folder engine/)
 * Fungsi: satu langkah catur (petak asal, petak tujuan, promosi) + konversi teks
 * untuk dikirim lewat jaringan. Petak 0..63: 0 = a8, 7 = h8, 56 = a1, 63 = h1.
 * Rokade = langkah raja 2 petak; en passant = pion jalan diagonal ke petak kosong
 * (keduanya dideteksi otomatis oleh Position.apply()).
 */
data class Move(val from: Int, val to: Int, val promo: Int = 0) {

    /** Format kabel jaringan: "dari,ke,promosi". */
    fun toWire(): String = "$from,$to,$promo"

    companion object {
        fun fromWire(s: String): Move? {
            val p = s.split(",")
            if (p.size != 3) return null
            val f = p[0].toIntOrNull() ?: return null
            val t = p[1].toIntOrNull() ?: return null
            val pr = p[2].toIntOrNull() ?: return null
            if (f !in 0..63 || t !in 0..63 || pr !in 0..6) return null
            return Move(f, t, pr)
        }

        fun squareIndex(name: String): Int {
            if (name.length != 2) return -1
            val c = name[0] - 'a'
            val r = '8' - name[1]
            return if (c in 0..7 && r in 0..7) r * 8 + c else -1
        }

        fun squareName(sq: Int): String = "${'a' + sq % 8}${'8' - sq / 8}"

        /** Notasi UCI, mis. "e2e4" atau "a7a8q" (dipakai di unit test). */
        fun fromUci(s: String): Move? {
            if (s.length < 4) return null
            val f = squareIndex(s.substring(0, 2))
            val t = squareIndex(s.substring(2, 4))
            if (f < 0 || t < 0) return null
            val promo = if (s.length > 4) when (s[4]) {
                'q' -> QUEEN
                'r' -> ROOK
                'b' -> BISHOP
                'n' -> KNIGHT
                else -> 0
            } else 0
            return Move(f, t, promo)
        }
    }
}
