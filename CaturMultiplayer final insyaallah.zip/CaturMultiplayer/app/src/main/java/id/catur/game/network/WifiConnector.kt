package id.catur.game.network

import android.os.Handler
import android.os.Looper
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/*
 * FILE: WifiConnector.kt  (folder network/)
 * Fungsi: koneksi via WiFi LAN / Hotspot memakai TCP socket (port Protocol.PORT).
 *  - WifiHost  : pemain "server", menunggu lawan masuk.
 *  - WifiClient: pemain "klien", menyambung ke IP host.
 * Hotspot: HP pemilik hotspot jadi Host; HP lain gabung ke WiFi hotspot lalu isi IP host
 * (biasanya otomatis terisi dari gateway, mis. 192.168.43.1).
 */
class WifiHost(private val callback: (GameConnection?, String?) -> Unit) : Cancelable {
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var server: ServerSocket? = null

    @Volatile
    private var cancelled = false

    fun start() {
        Thread({
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(Protocol.PORT))
                server = ss
                if (cancelled) {
                    ss.close()
                } else {
                    val s = ss.accept()
                    ss.close()
                    s.tcpNoDelay = true
                    val c = StreamConnection(s.getInputStream(), s.getOutputStream()) { s.close() }
                    c.start()
                    main.post { callback(c, null) }
                }
            } catch (e: IOException) {
                if (!cancelled) main.post { callback(null, e.message) }
            }
        }, "catur-wifi-host").start()
    }

    override fun cancel() {
        cancelled = true
        try {
            server?.close()
        } catch (e: IOException) {
            // abaikan
        }
    }
}

object WifiClient {
    fun connect(ip: String, callback: (GameConnection?, String?) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        Thread({
            try {
                val s = Socket()
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(ip, Protocol.PORT), 5000)
                val c = StreamConnection(s.getInputStream(), s.getOutputStream()) { s.close() }
                c.start()
                main.post { callback(c, null) }
            } catch (e: Exception) {
                main.post { callback(null, e.message) }
            }
        }, "catur-wifi-client").start()
    }
}
