package id.catur.game.network

import kotlin.random.Random

/*
 * FILE: Handshake.kt  (folder network/)
 * Fungsi: tahap "kenalan" di lobi sebelum partai dimulai.
 *   Kedua sisi mengirim HELLO (nama+rating). Host lalu mengirim START berisi warna lawan,
 *   waktu per pemain, dan token partai (dipakai untuk memastikan reconnect ke partai yang sama).
 */
data class Session(
    val myWhite: Boolean,
    val minutes: Int,
    val peerName: String,
    val peerRating: Int,
    val token: String
)

object Handshake {

    fun host(
        conn: GameConnection, myName: String, myRating: Int, hostWhite: Boolean, minutes: Int,
        onReady: (Session) -> Unit, onFail: () -> Unit
    ) {
        val token = java.lang.Long.toHexString(Random.nextLong())
        var done = false
        conn.send(Protocol.build(Protocol.HELLO, myName, myRating.toString()))
        conn.setListener(object : GameConnection.Listener {
            override fun onMessage(line: String) {
                val (type, a) = Protocol.parse(line)
                if (type == Protocol.HELLO && !done) {
                    done = true
                    val peer = a.getOrElse(0) { "Lawan" }
                    val rating = a.getOrNull(1)?.toIntOrNull() ?: 800
                    conn.send(Protocol.build(Protocol.START, if (hostWhite) "B" else "W", minutes.toString(), token))
                    onReady(Session(hostWhite, minutes, peer, rating, token))
                }
            }

            override fun onClosed() {
                if (!done) onFail()
            }
        })
    }

    fun client(
        conn: GameConnection, myName: String, myRating: Int,
        onReady: (Session) -> Unit, onFail: () -> Unit
    ) {
        var peer = "Lawan"
        var rating = 800
        var done = false
        conn.send(Protocol.build(Protocol.HELLO, myName, myRating.toString()))
        conn.setListener(object : GameConnection.Listener {
            override fun onMessage(line: String) {
                val (type, a) = Protocol.parse(line)
                if (type == Protocol.HELLO) {
                    peer = a.getOrElse(0) { "Lawan" }
                    rating = a.getOrNull(1)?.toIntOrNull() ?: 800
                } else if (type == Protocol.START && !done) {
                    done = true
                    val white = a.getOrNull(0) == "W"
                    val minutes = a.getOrNull(1)?.toIntOrNull() ?: 0
                    val token = a.getOrElse(2) { "" }
                    onReady(Session(white, minutes, peer, rating, token))
                }
            }

            override fun onClosed() {
                if (!done) onFail()
            }
        })
    }
}
