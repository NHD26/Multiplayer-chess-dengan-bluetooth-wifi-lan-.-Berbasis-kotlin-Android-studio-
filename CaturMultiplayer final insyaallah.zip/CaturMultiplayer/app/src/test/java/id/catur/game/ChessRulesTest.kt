package id.catur.game

import id.catur.game.engine.BISHOP
import id.catur.game.engine.ChessGame
import id.catur.game.engine.EndReason
import id.catur.game.engine.KNIGHT
import id.catur.game.engine.Move
import id.catur.game.engine.Outcome
import id.catur.game.engine.Position
import id.catur.game.engine.QUEEN
import id.catur.game.engine.ROOK
import id.catur.game.engine.KING
import id.catur.game.engine.PAWN
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/*
 * FILE: ChessRulesTest.kt  (folder app/src/test/)
 * Fungsi: UNIT TEST aturan catur. Jalankan: ./gradlew test  (atau klik kanan > Run di Android Studio).
 * Isi: perft (angka resmi Chess Programming Wiki) + skenario rokade, en passant, promosi,
 * skak, skakmat, stalemate, remis, dan "raja tidak boleh dimakan".
 */
class ChessRulesTest {

    private fun perft(p: Position, d: Int): Long =
        if (d == 0) 1L else p.legalMoves().sumOf { perft(p.apply(it), d - 1) }

    private fun mv(p: Position, uci: String): Position {
        val m = Move.fromUci(uci)!!
        assertTrue("Langkah ilegal: $uci", m in p.legalMoves())
        return p.apply(m)
    }

    private fun has(p: Position, uci: String) = Move.fromUci(uci)!! in p.legalMoves()

    // ---------------------------------------------------------------- perft (verifikasi generator langkah)

    @Test fun perftStartPosition() {
        val p = Position.initial()
        assertEquals(20L, perft(p, 1))
        assertEquals(400L, perft(p, 2))
        assertEquals(8902L, perft(p, 3))
        assertEquals(197281L, perft(p, 4))
    }

    @Test fun perftKiwipete() {
        val p = Position.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq -")
        assertEquals(48L, perft(p, 1))
        assertEquals(2039L, perft(p, 2))
        assertEquals(97862L, perft(p, 3))
    }

    @Test fun perftEnPassantPins() {
        val p = Position.fromFen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - -")
        assertEquals(14L, perft(p, 1))
        assertEquals(191L, perft(p, 2))
        assertEquals(2812L, perft(p, 3))
        assertEquals(43238L, perft(p, 4))
    }

    @Test fun perftPromotionsAndCastling() {
        val p = Position.fromFen("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq -")
        assertEquals(6L, perft(p, 1))
        assertEquals(264L, perft(p, 2))
        assertEquals(9467L, perft(p, 3))
    }

    // ---------------------------------------------------------------- raja tidak bisa dimakan

    @Test fun kingNeverCapturableInRandomGames() {
        val rnd = java.util.Random(1)
        repeat(60) {
            var p = Position.initial()
            for (ply in 0 until 150) {
                val legal = p.legalMoves()
                if (legal.isEmpty()) break
                for (m in legal) assertTrue(abs(p.board[m.to]) != KING)
                val mover = p.whiteToMove
                p = p.apply(legal[rnd.nextInt(legal.size)])
                assertFalse("Pihak yang baru jalan tidak boleh skak sendiri", p.inCheck(mover))
            }
        }
    }

    @Test fun pinnedPieceCannotMove() {
        val p = Position.fromFen("4k3/4r3/8/8/8/8/4N3/4K3 w - -")
        assertTrue(p.legalMoves().none { it.from == Move.squareIndex("e2") })
    }

    @Test fun kingsCannotBeAdjacent() {
        val p = Position.fromFen("8/8/8/8/8/4k3/8/4K3 w - -")
        for (sq in listOf("d2", "e2", "f2")) assertFalse(has(p, "e1$sq"))
    }

    // ---------------------------------------------------------------- rokade

    @Test fun castlingBothSides() {
        val p = Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq -")
        assertTrue(has(p, "e1g1"))
        assertTrue(has(p, "e1c1"))
        val k = mv(p, "e1g1")
        assertEquals(ROOK, k.board[Move.squareIndex("f1")])
        assertEquals(KING, k.board[Move.squareIndex("g1")])
        assertEquals(0, k.board[Move.squareIndex("h1")])
        val q = mv(p, "e1c1")
        assertEquals(ROOK, q.board[Move.squareIndex("d1")])
        assertEquals(0, q.board[Move.squareIndex("a1")])
    }

    @Test fun blackCastles() {
        val p = mv(Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq -"), "a1a2")
        assertTrue(has(p, "e8g8"))
        assertTrue(has(p, "e8c8"))
    }

    @Test fun noCastlingThroughOrOutOfCheck() {
        val through = Position.fromFen("r3k2r/8/8/8/8/5r2/8/R3K2R w KQkq -")
        assertFalse(has(through, "e1g1"))
        val inCheck = Position.fromFen("r3k2r/8/8/8/4r3/8/8/R3K2R w KQkq -")
        assertFalse(has(inCheck, "e1g1"))
        assertFalse(has(inCheck, "e1c1"))
    }

    @Test fun castlingRightsLost() {
        var p = Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq -")
        p = mv(p, "h1h2"); p = mv(p, "a8a7"); p = mv(p, "h2h1"); p = mv(p, "a7a8")
        assertFalse(has(p, "e1g1"))
        assertTrue(has(p, "e1c1"))
        var k = Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq -")
        k = mv(k, "e1e2"); k = mv(k, "a8a7"); k = mv(k, "e2e1"); k = mv(k, "a7a8")
        assertFalse(has(k, "e1g1")); assertFalse(has(k, "e1c1"))
        val cap = mv(Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq -"), "a1a8")
        assertFalse(has(cap, "e8c8"))
    }

    // ---------------------------------------------------------------- en passant & promosi

    @Test fun enPassant() {
        var p = Position.fromFen("4k3/8/8/8/3p4/8/4P3/4K3 w - -")
        p = mv(p, "e2e4")
        assertTrue(has(p, "d4e3"))
        val after = mv(p, "d4e3")
        assertEquals(0, after.board[Move.squareIndex("e4")])
        assertEquals(-PAWN, after.board[Move.squareIndex("e3")])
    }

    @Test fun enPassantExpires() {
        var p = Position.fromFen("4k3/8/8/8/3p4/8/4P3/4K3 w - -")
        p = mv(p, "e2e4"); p = mv(p, "e8d8"); p = mv(p, "e1e2")
        assertFalse(has(p, "d4e3"))
    }

    @Test fun promotionOffersFourPieces() {
        val p = Position.fromFen("1n2k3/P7/8/8/8/8/8/4K3 w - -")
        val pushes = p.legalMoves().filter { it.from == Move.squareIndex("a7") && it.to == Move.squareIndex("a8") }
        assertEquals(setOf(QUEEN, ROOK, BISHOP, KNIGHT), pushes.map { it.promo }.toSet())
        val caps = p.legalMoves().filter { it.from == Move.squareIndex("a7") && it.to == Move.squareIndex("b8") }
        assertEquals(setOf(QUEEN, ROOK, BISHOP, KNIGHT), caps.map { it.promo }.toSet())
        assertTrue(p.legalMoves().filter { it.from == Move.squareIndex("a7") }.all { it.promo != 0 })
        assertEquals(QUEEN, mv(p, "a7a8q").board[Move.squareIndex("a8")])
        assertEquals(KNIGHT, mv(p, "a7b8n").board[Move.squareIndex("b8")])
    }

    @Test fun blackPromotes() {
        val p = Position.fromFen("4k3/8/8/8/8/8/p7/4K3 b - -")
        assertTrue(p.legalMoves().any { it.promo == KNIGHT })
        assertEquals(-QUEEN, mv(p, "a2a1q").board[Move.squareIndex("a1")])
    }

    // ---------------------------------------------------------------- skak, skakmat, remis

    @Test fun foolsMateIsCheckmate() {
        val g = ChessGame()
        for (u in listOf("f2f3", "e7e5", "g2g4", "d8h4")) assertTrue(g.play(Move.fromUci(u)!!))
        assertEquals(Outcome.BLACK_WIN, g.outcome)
        assertEquals(EndReason.CHECKMATE, g.reason)
        assertEquals("Qh4#", g.records.last().san)
        assertFalse(g.play(Move.fromUci("a2a3")!!))   // setelah selesai tidak bisa jalan lagi
    }

    @Test fun checkIsDetectedAndMustBeAnswered() {
        val p = Position.fromFen("4k3/8/8/8/8/8/3q4/4K3 w - -")
        assertTrue(p.inCheck())
        assertTrue(p.legalMoves().all { it.from == Move.squareIndex("e1") })
    }

    @Test fun stalemateIsDraw() {
        val p = Position.fromFen("7k/5Q2/6K1/8/8/8/8/8 b - -")
        assertTrue(p.legalMoves().isEmpty())
        assertFalse(p.inCheck())
        val g = ChessGame(Position.fromFen("7k/8/6K1/8/8/8/8/5Q2 w - -"))
        assertTrue(g.play(Move.fromUci("f1f7")!!))
        assertEquals(Outcome.DRAW, g.outcome)
        assertEquals(EndReason.STALEMATE, g.reason)
    }

    @Test fun insufficientMaterialIsDraw() {
        val g = ChessGame(Position.fromFen("4k3/8/8/8/8/8/4n3/4K3 w - -"))
        assertTrue(g.play(Move.fromUci("e1e2")!!))      // raja memakan kuda -> K vs K
        assertEquals(Outcome.DRAW, g.outcome)
        assertEquals(EndReason.INSUFFICIENT_MATERIAL, g.reason)
    }

    @Test fun fiftyMoveRuleIsDraw() {
        val g = ChessGame(Position.fromFen("4k3/8/8/8/8/8/8/R3K3 w - - 99 80"))
        assertTrue(g.play(Move.fromUci("a1a2")!!))
        assertEquals(Outcome.DRAW, g.outcome)
        assertEquals(EndReason.FIFTY_MOVE, g.reason)
    }

    @Test fun backRankMate() {
        val g = ChessGame(Position.fromFen("6k1/5ppp/8/8/8/8/8/R3K3 w - -"))
        assertTrue(g.play(Move.fromUci("a1a8")!!))
        assertEquals(Outcome.WHITE_WIN, g.outcome)
        assertEquals(EndReason.CHECKMATE, g.reason)
    }

    @Test fun threefoldRepetitionIsDraw() {
        val g = ChessGame()
        val cycle = listOf("g1f3", "g8f6", "f3g1", "f6g8")
        repeat(2) { for (u in cycle) assertTrue(g.play(Move.fromUci(u)!!)) }
        assertEquals(Outcome.DRAW, g.outcome)
        assertEquals(EndReason.REPETITION, g.reason)
    }

    @Test fun undoRestoresPosition() {
        val g = ChessGame()
        g.play(Move.fromUci("e2e4")!!)
        g.play(Move.fromUci("e7e5")!!)
        g.undo(2)
        assertEquals(0, g.moveCount)
        assertTrue(g.position.whiteToMove)
        assertEquals(20, g.legalMoves().size)
    }
}
