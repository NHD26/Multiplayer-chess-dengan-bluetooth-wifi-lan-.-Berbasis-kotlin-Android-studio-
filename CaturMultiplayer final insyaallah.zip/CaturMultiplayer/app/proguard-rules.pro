# Aturan ProGuard/R8 (kosong: minify dimatikan).
